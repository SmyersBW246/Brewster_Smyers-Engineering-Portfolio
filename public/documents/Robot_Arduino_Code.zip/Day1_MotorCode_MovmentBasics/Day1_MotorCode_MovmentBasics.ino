// Initializatons
int PWMA = 11;
int Ain1 = 12;
int Ain2 = 13;
int PWMB = 10; 
int Bin1 = A4;
int Bin2 = A5;
double velocity = 100;
double turnRatio = 0;
bool offWheel = 1;


// Edit here

//********************************************//
// Setup function

void setup() {
  pinMode(PWMA, OUTPUT);
  pinMode(Ain1, OUTPUT);
  pinMode(Ain2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  pinMode(Bin1, OUTPUT);
  pinMode(Bin2, OUTPUT);
  Serial.begin(9600);

}

//********************************************//
// Loop function

void loop() {
  forward(100);
  delay(1000);
  backward(100);
  delay(1000);
  turnRight(100);
  delay(1000);
  turnLeft(100);
  delay(1000);

}

//********************************************//
// Motor functions

// The direction functions send commands to 
// the motor driver in the following format:
// runMotor(*which motor*, *how fast*, *what direction*);
//
// Motor A is 1, Motor B is 0
//
// Speed is how fast out of 250
//
// turnRatio is the speed of the off-wheel in compasiron to
// the turning wheel
//
// turnWheel is the direction of the off-wheel, forward for
// wide turns, backward for sharp turns
//
// Forward is 1, Backward is 0


// Motor A forward at full speed, Motor B backward at quarter speed
void turnLeft(int spd) {
  runMotor(1, spd, 1);
  runMotor(0, spd*turnRatio, offWheel);
}

// Motor A backward at quarter speed, Motor B forward at full speed
void turnRight(int spd) {
  runMotor(1, spd*turnRatio, offWheel);
  runMotor(0, spd, 1);
}

// Both Motors forward at full speed
void forward(int spd) {
  runMotor(1, spd, 1);
  runMotor(0, spd, 1);
}

// Both Motors backward at full speed
void backward(int spd) {
  runMotor(0, spd, 0);
  runMotor(1, spd, 0);
}





// The runMotor function writes the motor, direction, and 
// speed information to the motor driver

void runMotor(int motor, int spd, int dir) {
  boolean dirPin1 = LOW;
  boolean dirPin2 = HIGH;

  if(dir == 1) {
    dirPin1 = HIGH;
    dirPin2 = LOW;
  }

  if(motor == 1) {
    analogWrite(PWMA, spd);
    digitalWrite(Ain1, dirPin1);
    digitalWrite(Ain2, dirPin2);
  } else {
    analogWrite(PWMB, spd);
    digitalWrite(Bin1, dirPin1);
    digitalWrite(Bin2, dirPin2);
  }
}

// Credit to: Maker's Digest 
// This code for the TB6612 Motor Driver is an adapted version of the tutorial from Maker's Digest on how to use said motor driver
// Their full tutorial can be found here: https://github.com/makersdigest/T06-TB6612FNG-Motor-Controller
