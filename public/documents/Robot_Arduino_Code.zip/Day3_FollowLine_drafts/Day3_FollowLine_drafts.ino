int PWMA = 11;
int Ain1 = 12;
int Ain2 = 13;
int PWMB = 10; 
int Bin1 = A4;
int Bin2 = A5;
double velocity = 100;
double turnRatio = 0.2;
bool offWheel = 1;
int driveTime = 50;

// Include the QTR Sensor Library and load as reflect_snsr

#include <QTRSensors.h>

QTRSensors reflect_snsr;


//********************************************//
// Initializatons for various sensor value arrays

// Number of sensors on the strip
const uint8_t sensorCount = 8;

// An array for the raw sensor data
uint16_t sensorValues[sensorCount];

// An array for the position of the sensor
uint16_t sensorPosition[sensorCount];

// Initializations for some variables that will be used later
int lineCount;
int linePosition = 0;

// Assign threshold for line detection
int threshold = 1000;

// Initialize variable which marks the center of the line
int center;


void setup() {
  // put your setup code here, to run once:
  pinMode(PWMA, OUTPUT);
  pinMode(Ain1, OUTPUT);
  pinMode(Ain2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  pinMode(Bin1, OUTPUT);
  pinMode(Bin2, OUTPUT);
  // Configure the sensors as pins 2-9 (1 and 0 don't work because they are used for serial)
  reflect_snsr.setTypeRC();
  reflect_snsr.setSensorPins((const uint8_t[]){2, 3, 4, 5, 6, 7, 8, 9}, sensorCount);

  // Start the serial interface
  Serial.begin(9600);

}

void loop() {

 center = sense();

  // if((lineCount == 8) or (lineCount == 0)) {
  //   forward(0);


  //   // Test whether the line is indeed read by some of the sensors
  // } 
  // else if (!(linePosition == 0)) {

    // If the line's position is greater than 0, do what?
  
    if (center > 1) {
      // if(center >= 4)
      // {
      //   if(center >= 6)
      //   {
      //     turnRight(150);
      //     delay(driveTime);
      //   }
      //   else
      //   {
      //     turnRight(100);
      //     delay(driveTime);
      //   }
        
      // }
      // else
      // {
      //   turnRight(75);
      //   delay(driveTime);
      // }
      // // If the line's position is less than 0, do what?
      delay(driveTime);
      turnRight(20);
      
      while(center > 6 && !(center > 7.9) && !(center == 8))
      {
        delay(driveTime);
        turnRight(40);
        center = sense();
      }
    } 
    else if (center < -1) {

      // add direction here
      // if(center >= -4)
      // {
      //   if(center >= -6)
      //   {
      //     turnLeft(150);
      //     delay(driveTime);
      //   }
      //   else
      //   {
      //     turnLeft(100);
      //     delay(driveTime);
      //   }
        
      // }
      // else
      // {
      //   turnLeft(75);
      //   delay(driveTime);
      // }

      // If the line's position is 0, do what?
      delay(driveTime);
      turnLeft(20);
      while(center > -6  && !(center < -7.9) && !(center == 8))
      {
        delay(driveTime);
        turnLeft(40);
        center = sense();
      }

    } 
    else {

      // add direction here
    
      delay(driveTime);
      forward(velocity);
    }
  //}
}



int sense()
{
   // edit here for steps 19-23
  reflect_snsr.read(sensorValues);

  for(int i = 0; i < sensorCount; i++)
  {
    Serial.println(sensorValues[i]);
  }
  Serial.println("\n\n");
  //********************************************//
  // Reset the position and count for the new read
  linePosition = 0;
  lineCount = 0;


  // Multiply the resulting array elements by 2 times the position of the 
  // corresponding sensor plus one (odd numbers 1-15) if the value is above
  // the threshold, otherwise set the array element to zero
  for (int i = 0; i < sensorCount; i++) {
    if (sensorValues[i] >= threshold) {
      sensorPosition[i] = (2*i) + 1;
      lineCount = lineCount + 1;
    } else {
      sensorPosition[i] = 0;
    }

    // Start to take the average by adding the values
    linePosition = linePosition + sensorPosition[i];
  }


  // Finish taking the average. If any sensors see the line, divide the position
  // by the number of lines to get the center. This test is just in case no 
  // sensors see it, which would otherwise have the robot try to divide by zero
  if (!(lineCount==0)) {
    linePosition = linePosition/lineCount;    
  }


  // To make zero the center of the line, we subtract 8
  center = linePosition-8;

  // Print where the line is
  Serial.println(center);
  Serial.println(" "); Serial.println(" ");  //********************************************//

  // Test whether none of the sensors see the line (not on the line or threshold
  // too high) or whether all of the sensors see the line (wrong way on the line
  // or, more likely, the robot is looking off the edge of a table). For both of
  // these cases, stop moving
  //
  // This is the auto-break system

  Serial.println(lineCount);
  Serial.println(linePosition);
  Serial.println(center);
  return(center);
}


//********************************************//
// Motor functions

// The direction functions send commands to 
// the motor driver in the following format:
// runMotor(*which motor*, *how fast*, *what direction*);
//
// Motor A is 1, Motor B is 0
//
// Speed is how fast out of 250
//
// turnRatio is the speed of the off-wheel in compasiron to
// the turning wheel
//
// turnWheel is the direction of the off-wheel, forward for
// wide turns, backward for sharp turns
//
// Forward is 1, Backward is 0


// Motor A forward at full speed, Motor B backward at quarter speed
void turnLeft(int spd) {
  runMotor(1, spd, 1);
  runMotor(0, spd*turnRatio, offWheel);
}

// Motor A backward at quarter speed, Motor B forward at full speed
void turnRight(int spd) {
  runMotor(1, spd*turnRatio, offWheel);
  runMotor(0, spd, 1);
}

// Both Motors forward at full speed
void forward(int spd) {
  runMotor(1, spd, 1);
  runMotor(0, spd, 1);
}

// Both Motors backward at full speed
void backward(int spd) {
  runMotor(0, spd, 0);
  runMotor(1, spd, 0);
}





// The runMotor function writes the motor, direction, and 
// speed information to the motor driver

void runMotor(int motor, int spd, int dir) {
  boolean dirPin1 = LOW;
  boolean dirPin2 = HIGH;

  if(dir == 1) {
    dirPin1 = HIGH;
    dirPin2 = LOW;
  }

  if(motor == 1) {
    analogWrite(PWMA, spd);
    digitalWrite(Ain1, dirPin1);
    digitalWrite(Ain2, dirPin2);
  } else {
    analogWrite(PWMB, spd);
    digitalWrite(Bin1, dirPin1);
    digitalWrite(Bin2, dirPin2);
  }
}


