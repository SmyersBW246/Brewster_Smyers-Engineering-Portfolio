// Include the QTR Sensor Library and load as reflect_snsr

#include <QTRSensors.h>

QTRSensors reflect_snsr;


//********************************************//
// Initializatons for various sensor value arrays

// Number of sensors on the strip
const uint8_t sensorCount = 8;

// An array for the raw sensor data
uint16_t sensorValues[sensorCount];

// An array for the position of the sensor
uint16_t sensorPosition[sensorCount];

// Initializations for some variables that will be used later
int lineCount;
int linePosition = 0;

// Assign threshold for line detection
int threshold = 1500;

// Initialize variable which marks the center of the line
int center;


// Initializatons
int PWMA = 11;
int Ain1 = 12;
int Ain2 = 13;
int PWMB = 10; 
int Bin1 = A4;
int Bin2 = A5;
int potentch = A0;
int LDR = A1; 
double velo = 100;
double turnRatio = 0;
bool offWheel = 1;
int driveTime = 50;




void setup() {
  pinMode(PWMA, OUTPUT);
  pinMode(Ain1, OUTPUT);
  pinMode(Ain2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  pinMode(Bin1, OUTPUT);
  pinMode(Bin2, OUTPUT);
  pinMode(potentch, INPUT);
  pinMode(LDR, INPUT);
  // Configure the sensors as pins 2-9 (1 and 0 don't work because they are used for serial)
  reflect_snsr.setTypeRC();
  reflect_snsr.setSensorPins((const uint8_t[]){2, 3, 4, 5, 6, 7, 8, 9}, sensorCount);
  Serial.begin(9600);
}

void loop()
{

  Serial.println("The reading of the Potentiometer is: ");
  Serial.println(analogRead(potentch));
  Serial.println("\n\n");

  velo = analogRead(potentch)*(250.0/1023.0);
  Serial.println("The adjusted speed of the Robot is: ");
  Serial.println(velo);

  int ldrVal = analogRead(LDR);
  float volt = ldrVal * (5.0/1023.0);

  reflect_snsr.read(sensorValues);

  for(int i = 0; i < sensorCount; i++)
  {
    Serial.println(sensorValues[i]);
  }
  Serial.println("\n\n");
  //********************************************//
  // Reset the position and count for the new read
  linePosition = 0;
  lineCount = 0;


  // Multiply the resulting array elements by 2 times the position of the 
  // corresponding sensor plus one (odd numbers 1-15) if the value is above
  // the threshold, otherwise set the array element to zero
  for (int i = 0; i < sensorCount; i++) 
  {
    if (sensorValues[i] >= threshold) 
    {
      sensorPosition[i] = (2*i) + 1;
      lineCount = lineCount + 1;
    } 
    else 
    {
      sensorPosition[i] = 0;
    }

    // Start to take the average by adding the values
    linePosition = linePosition + sensorPosition[i];
  }


  // Finish taking the average. If any sensors see the line, divide the position
  // by the number of lines to get the center. This test is just in case no 
  // sensors see it, which would otherwise have the robot try to divide by zero
  if (!(lineCount==0)) 
  {
    linePosition = linePosition/lineCount;    
  }


  // To make zero the center of the line, we subtract 8
  center = linePosition-8;

  // Print where the line is
  Serial.println(center);
  Serial.println(" "); Serial.println(" ");  //********************************************//

  // Test whether none of the sensors see the line (not on the line or threshold
  // too high) or whether all of the sensors see the line (wrong way on the line
  // or, more likely, the robot is looking off the edge of a table). For both of
  // these cases, stop moving
  //
  // This is the auto-break system

  //Serial.println(lineCount);
  //Serial.println(linePosition);
  Serial.println("The center of the sensor val reads: ");
  Serial.println(center);


  if ((lineCount == 8) or (lineCount == 0) or (volt > 4.0)) 
  {
    forward(0);
    if(volt > 4.0)
    {
      Serial.println("The lights are off, the Robot is not Moving.\n");
    }
  }
  else if (!(linePosition == 0)) 
  {
    if (center > 0) 
    {

      // if(center > 5)
      // {
      //   turnLeft(velo);
      //   delay(driveTime);
      //   turnLeft(velo);
      //   delay(driveTime);
      //   forward(velo);
      //   delay(driveTime);
      // }
      turnLeft(velo);

      delay(driveTime);

      forward(velo);
    } 
    else if (center < 0) 
    {

      // if(center < -5)
      // {
      //   turnRight(velo);
      //   delay(driveTime);
      //   turnRight(velo);
      //   delay(driveTime);
      //   forward(velo);
      //   delay(driveTime);
      // }
      
      turnRight(velo);
  
      delay(driveTime);

      forward(velo);
    } 
    else 
    {
      
      forward(velo);

      delay(driveTime);
      
      forward(velo);
    }
  }
}



void turnLeft(int spd) 
{
  runMotor(1, spd, 1);
  runMotor(0, spd*turnRatio, offWheel);
}

// Motor A backward at quarter speed, Motor B forward at full speed
void turnRight(int spd) 
{
  runMotor(1, spd*turnRatio, offWheel);
  runMotor(0, spd, 1);
}

// Both Motors forward at full speed
void forward(int spd) 
{
  runMotor(1, spd, 1);
  runMotor(0, spd, 1);
}

// Both Motors backward at full speed
void backward(int spd) 
{
  runMotor(0, spd, 0);
  runMotor(1, spd, 0);
}

// The runMotor function writes the motor, direction, and 
// speed information to the motor driver

void runMotor(int motor, int spd, int dir) 
{
  boolean dirPin1 = LOW;
  boolean dirPin2 = HIGH;

  if(dir == 1) {
    dirPin1 = HIGH;
    dirPin2 = LOW;
  }

  if(motor == 1) {
    analogWrite(PWMA, spd);
    digitalWrite(Ain1, dirPin1);
    digitalWrite(Ain2, dirPin2);
  } else {
    analogWrite(PWMB, spd);
    digitalWrite(Bin1, dirPin1);
    digitalWrite(Bin2, dirPin2);
  }
}
