// Include the QTR Sensor Library and load as reflect_snsr

#include <QTRSensors.h>

QTRSensors reflect_snsr;


//********************************************//
// Initializatons for various sensor value arrays

// Number of sensors on the strip
const uint8_t sensorCount = 8;

// An array for the raw sensor data
uint16_t sensorValues[sensorCount];

// An array for the position of the sensor
uint16_t sensorPosition[sensorCount];

// Initializations for some variables that will be used later
int lineCount;
int linePosition = 0;

// Assign threshold for line detection
int threshold = 1000;

// Initialize variable which marks the center of the line
int center;


//********************************************//
// Setup function

void setup() {
  
  // Configure the sensors as pins 2-9 (1 and 0 don't work because they are used for serial)
  reflect_snsr.setTypeRC();
  reflect_snsr.setSensorPins((const uint8_t[]){2, 3, 4, 5, 6, 7, 8, 9}, sensorCount);

  // Start the serial interface
  Serial.begin(9600);
}

//********************************************//
// Loop function

void loop() {

  // edit here for steps 19-23
  reflect_snsr.read(sensorValues);

  for(int i = 0; i < sensorCount; i++)
  {
    Serial.println(sensorValues[i]);
  }
  Serial.println("\n\n");
  //********************************************//
  // Reset the position and count for the new read
  linePosition = 0;
  lineCount = 0;


  // Multiply the resulting array elements by 2 times the position of the 
  // corresponding sensor plus one (odd numbers 1-15) if the value is above
  // the threshold, otherwise set the array element to zero
  for (int i = 0; i < sensorCount; i++) {
    if (sensorValues[i] >= threshold) {
      sensorPosition[i] = (2*i) + 1;
      lineCount = lineCount + 1;
    } else {
      sensorPosition[i] = 0;
    }

    // Start to take the average by adding the values
    linePosition = linePosition + sensorPosition[i];
  }


  // Finish taking the average. If any sensors see the line, divide the position
  // by the number of lines to get the center. This test is just in case no 
  // sensors see it, which would otherwise have the robot try to divide by zero
  if (!(lineCount==0)) {
    linePosition = linePosition/lineCount;    
  }


  // To make zero the center of the line, we subtract 8
  center = linePosition-8;

  // Print where the line is
  Serial.println(center);
  Serial.println(" "); Serial.println(" ");  //********************************************//
  
  delay(500);
}
