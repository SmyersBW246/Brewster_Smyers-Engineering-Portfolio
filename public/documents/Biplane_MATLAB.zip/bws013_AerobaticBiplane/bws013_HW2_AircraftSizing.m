function mission = bws013_HW2_AircraftSizing(cfg)
% HW2: dimensional piston-engine fuel accounting and explicit weight buildup.
% No jet TSFC/Breguet expression and no Spitfire empty-weight regression.
% Known 1155 lb reference empty weight INCLUDES unusable fuel: do not add it
% again. Loaded fuel below is usable fuel only. Reserve is carried, not flown.

assert(numel(cfg.mass.occupants_lb)==2,'This design has two occupants.');
assert(all(cfg.mass.occupants_lb>0),'Both occupants must have positive weight.');
assert(numel(cfg.mass.worn_equipment_lb)==2,'Specify worn equipment per seat.');
assert(cfg.mission.distance_each_nm>0 && cfg.mission.cruise_TAS_kt>0 ...
    && cfg.mission.cruise_TAS_kt+cfg.mission.headwind_kt>0 ...
    && cfg.mission.cruise_TAS_kt-cfg.mission.headwind_kt>0,'Invalid cruise/ground speeds.');
assert(cfg.fuel.reserve_min>=30 && cfg.fuel.contingency_fraction>=0,'Invalid fuel margins.');
mission.names = {'Taxi / runup','Takeoff to 50 ft','Climb','Outbound cruise', ...
    'Aerobatics','Return cruise','Descent','Approach / landing','Taxi in'};
mission.alt_start_ft = [0,0,50,cfg.mission.altitude_ft,cfg.mission.altitude_ft, ...
    cfg.mission.altitude_ft,cfg.mission.altitude_ft,1000,0];
mission.alt_end_ft = [0,50,cfg.mission.altitude_ft,cfg.mission.altitude_ft, ...
    cfg.mission.altitude_ft,cfg.mission.altitude_ft,1000,0,0];
mission.time_min = [cfg.mission.taxi_out_min,cfg.mission.takeoff_min, ...
    (cfg.mission.altitude_ft-50)/cfg.mission.climb_fpm, ...
    60*cfg.mission.distance_each_nm/(cfg.mission.cruise_TAS_kt-cfg.mission.headwind_kt), ...
    cfg.mission.aerobatic_min, ...
    60*cfg.mission.distance_each_nm/(cfg.mission.cruise_TAS_kt+cfg.mission.headwind_kt), ...
    (cfg.mission.altitude_ft-1000)/cfg.mission.descent_fpm, ...
    cfg.mission.approach_min,cfg.mission.taxi_in_min];
assert(all(mission.time_min>0),'Every scheduled phase must have positive duration.');
mission.flow_gph = cfg.fuel.phase_flow_gph;
assert(numel(mission.flow_gph)==numel(mission.names) && all(mission.flow_gph>0), ...
    'Supply one positive fuel flow per mission phase.');
mission.burn_gal = mission.flow_gph.*mission.time_min/60;
mission.trip_gal = sum(mission.burn_gal);
mission.reserve_gal = cfg.fuel.reserve_min/60*cfg.fuel.reserve_flow_gph;
mission.contingency_gal = cfg.fuel.contingency_fraction*mission.trip_gal;
mission.minimum_dispatch_gal = mission.trip_gal+mission.reserve_gal+mission.contingency_gal;
if cfg.fuel.dispatch_usable_gal==0
    mission.dispatch_gal = mission.minimum_dispatch_gal;
else
    mission.dispatch_gal = cfg.fuel.dispatch_usable_gal;
end
assert(mission.dispatch_gal>=mission.minimum_dispatch_gal-1e-9, ...
    'Dispatch fuel is below trip + contingency + protected reserve.');
assert(mission.dispatch_gal<=cfg.fuel.main_usable_gal+1e-9, ...
    'Aerobatic mission exceeds main-tank usable capacity. Wing tank must be empty.');
assert(cfg.fuel.wing_loaded_gal==0,'Wing-tank fuel is excluded from aerobatic missions.');
mission.payload_lb = sum(cfg.mass.occupants_lb)+sum(cfg.mass.worn_equipment_lb)+cfg.mass.baggage_lb;
mission.dry_loaded_lb = cfg.mass.empty_lb+mission.payload_lb;
mission.ramp_lb = mission.dry_loaded_lb+mission.dispatch_gal*cfg.fuel.density_lb_gal;
mission.burn_lb = mission.burn_gal*cfg.fuel.density_lb_gal;
mission.weight_end_lb = mission.ramp_lb-cumsum(mission.burn_lb);
mission.weight_start_lb = [mission.ramp_lb,mission.weight_end_lb(1:end-1)];
mission.weight_mean_lb = (mission.weight_start_lb+mission.weight_end_lb)/2;
mission.fuel_start_gal = (mission.weight_start_lb-mission.dry_loaded_lb)/cfg.fuel.density_lb_gal;
mission.fuel_end_gal = (mission.weight_end_lb-mission.dry_loaded_lb)/cfg.fuel.density_lb_gal;
mission.takeoff_lb = mission.weight_start_lb(2); % brake release, after taxi
mission.W_lb = mission.takeoff_lb;
mission.W_kg = mission.takeoff_lb*0.45359237;
mission.landing_lb = mission.weight_end_lb(8);  % touchdown, before taxi in
mission.final_lb = mission.weight_end_lb(end);
mission.fraction = mission.weight_end_lb./mission.weight_start_lb;
% Seven grouped fractions retain the original homework's sequence; group 6
% is descent, NOT the protected reserve. Group 7 includes landing + taxi in.
mission.W1_W0 = prod(mission.fraction(1:2));
mission.W2_W1 = mission.fraction(3);
mission.W3_W2 = mission.fraction(4);
mission.W4_W3 = mission.fraction(5);
mission.W5_W4 = mission.fraction(6);
mission.W6_W5 = mission.fraction(7);
mission.W7_W6 = prod(mission.fraction(8:9));
mission.block_time_min = sum(mission.time_min);
mission.airborne_min = sum(mission.time_min(2:8));
mission.time_edges_min = [0,cumsum(mission.time_min)];
mission.ROC_fpm = (mission.alt_end_ft-mission.alt_start_ft)./mission.time_min;
mission.alt_eval_ft = max(mission.alt_start_ft,mission.alt_end_ft);
mission.alt_eval_ft(2)=0;    % ground run at sea level
mission.airborne = [false,true,true,true,true,true,true,true,false];
mission.load_factor = [0,1,1,1,cfg.mission.aerobatic_g,1,1,1,0];
% Available phase power is a ceiling; pilots can throttle back in descent.
% Rich fuel flow is budgeted independently, rather than assuming lean-cruise
% BSFC during takeoff or aerobatics.
lapse = interp1(cfg.engine.altitude_ft,cfg.engine.power_fraction, ...
    cfg.mission.altitude_ft,'linear');
mission.power_hp = cfg.engine.rated_hp*[cfg.mission.taxi_fraction_of_rated_power,1, ...
    cfg.mission.climb_fraction_of_available_power*lapse, ...
    cfg.mission.cruise_fraction_of_rated_power, ...
    cfg.mission.aerobatic_fraction_of_available_power*lapse, ...
    cfg.mission.cruise_fraction_of_rated_power, ...
    cfg.mission.descent_fraction_of_rated_power, ...
    cfg.mission.approach_fraction_of_rated_power,cfg.mission.taxi_fraction_of_rated_power];
maxPower=cfg.engine.rated_hp*interp1(cfg.engine.altitude_ft,cfg.engine.power_fraction,mission.alt_eval_ft);
assert(all(mission.power_hp(mission.airborne)>0) ...
    && all(mission.power_hp(mission.airborne)<=maxPower(mission.airborne)+1e-8), ...
    'Commanded phase power exceeds the altitude-lapsed engine capability.');
mission.eta_prop = [0,cfg.prop.eta_takeoff,cfg.prop.eta_climb,cfg.prop.eta_cruise, ...
    cfg.prop.eta_aerobatic,cfg.prop.eta_cruise,cfg.prop.eta_descent,cfg.prop.eta_approach,0];
mission.speed_value_kt = [0,NaN,82,cfg.mission.cruise_TAS_kt, ...
    cfg.mission.aerobatic_EAS_kt,cfg.mission.cruise_TAS_kt,100,NaN,0];
mission.speed_is_EAS = [false,true,true,false,true,false,true,true,false];
mission.nominal_land_reserve_min = mission.fuel_end_gal(end)/cfg.fuel.reserve_flow_gph*60;
assert(mission.ramp_lb<=cfg.mass.max_normal_lb,'Ramp weight exceeds conservative gross check.');
assert(mission.takeoff_lb<=cfg.mass.max_normal_lb,'Takeoff weight exceeds gross limit.');
assert(mission.weight_start_lb(5)<=cfg.mass.max_aerobatic_lb,'Aerobatic entry is overweight.');
assert(mission.fuel_end_gal(end)>=mission.reserve_gal-1e-9,'Protected fuel reserve was consumed.');
assert(abs(mission.ramp_lb-mission.final_lb-sum(mission.burn_lb))<1e-7,'Fuel mass does not close.');
end
