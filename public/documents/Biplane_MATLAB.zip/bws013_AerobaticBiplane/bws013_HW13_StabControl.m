function stab = bws013_HW13_StabControl(cfg,g,W_lb,fuel_gal,VM,CL_required,alpha_deg,dele_up_deg)
% HW13: stick-fixed neutral point, mass-budget CG, and simultaneous L/M trim.
% [] for alpha and elevator solves both unknowns. Otherwise evaluates the
% specified point. CG is NOT selected by subtracting a desired static margin
% from the neutral point. Replace assumed mass stations with CAD properties.
if nargin<7, alpha_deg=[]; end
if nargin<8, dele_up_deg=[]; end
assert(isempty(alpha_deg)==isempty(dele_up_deg),'Supply both angles or neither.');
fuel_lb = fuel_gal*cfg.fuel.density_lb_gal;
crew = cfg.mass.occupants_lb+cfg.mass.worn_equipment_lb;
expected_W = cfg.mass.empty_lb+sum(crew)+cfg.mass.baggage_lb+fuel_lb;
assert(abs(expected_W-W_lb)<1e-6,'CG weight and mission weight disagree.');
moment = cfg.mass.empty_lb*cfg.mass.empty_cg_x_ft ...
    +sum(crew.*cfg.mass.seat_x_ft)+cfg.mass.baggage_lb*cfg.mass.baggage_x_ft ...
    +fuel_lb*cfg.mass.main_fuel_x_ft;
stab.xcg_ft = moment/W_lb;
lift0 = bws013_HW12_Lift(cfg,g,VM,0,0);
aw = lift0.CL_alpha_w; ah = lift0.CL_alpha_t;
qh = lift0.Ettah; r = g.SrefHt/g.SrefW;
down = 1-cfg.aero.downwash_gradient;
aT = lift0.CL_alpha_T;
c = g.cbarW;
stab.xnp_ft = (aw*g.x_wing_ac_ft+qh*r*ah*down*g.x_HT_ac_ft ...
    -cfg.aero.Cm_alpha_fuselage*c)/aT;
stab.xnp = (stab.xnp_ft-g.x_mac_LE_ft)/c;
stab.xcg = (stab.xcg_ft-g.x_mac_LE_ft)/c;
stab.SM = (stab.xnp_ft-stab.xcg_ft)/c;
hw = (stab.xcg_ft-g.x_wing_ac_ft)/c;
hh = (g.x_HT_ac_ft-stab.xcg_ft)/c;
CL0 = lift0.CL_T;
Cm0 = cfg.aero.Cm0+lift0.CL_w*hw-qh*r*lift0.CL_t*hh;
Cma = aw*hw-qh*r*ah*down*hh+cfg.aero.Cm_alpha_fuselage;
CLde = -qh*r*ah*lift0.tau_e;      % derivative per radian of UP elevator
Cmde = qh*r*ah*lift0.tau_e*hh;
if isempty(alpha_deg)
    solution = [aT,CLde;Cma,Cmde]\[CL_required-CL0;-Cm0];
    alpha_deg = solution(1)*180/pi;
    dele_up_deg = solution(2)*180/pi;
end
lift = bws013_HW12_Lift(cfg,g,VM,alpha_deg,dele_up_deg);
stab.alpha_deg = alpha_deg;
stab.dele_up_deg = dele_up_deg;
stab.CL_T = lift.CL_T;
stab.CL_w = lift.CL_w;
stab.CL_t = lift.CL_t;
stab.Cmcg = cfg.aero.Cm0+cfg.aero.Cm_alpha_fuselage*alpha_deg*pi/180 ...
    +lift.CL_w*hw-qh*r*lift.CL_t*hh;
stab.Cm_alpha = Cma;
stab.dCm_ddele_up_per_rad = Cmde;
stab.slope_identity_error = Cma+aT*stab.SM;
stab.trim_valid = all(lift.valid_linear) ...
    && abs(dele_up_deg)<=cfg.controls.elevator_limit_deg;
end
