function lift = bws013_HW12_Lift(cfg,g,VM,alpha_deg,dele_up_deg)
% HW12: finite-wing slopes; total-area biplane convention throughout.
% Positive elevator means trailing edge UP: it DECREASES tail lift.
% Tail dynamic-pressure ratio and airfoil slope efficiency are distinct.
% Post-stall behavior/spin dynamics are not predicted by this linear model.
if nargin<5, dele_up_deg=0; end
assert(VM>=0 && VM<0.4,'Lift model requires 0 <= Mach < 0.4.');
beta = sqrt(1-VM^2);
a0 = 2*pi/beta;
lift.CL_alpha_w = 1/(1/a0+1/(pi*cfg.aero.e_ref*g.AR_ref));
lift.CL_alpha_t = 1/(1/a0+1/(pi*cfg.aero.e_tail*g.AR_Ht));
lift.Ettah = cfg.aero.tail_q_ratio;
r = cfg.controls.elevator_chord_ratio;
lift.tau_e = 1.576*r^3-3.458*r^2+2.882*r;
lift.downwash_gradient = cfg.aero.downwash_gradient;
alpha = alpha_deg*pi/180;
lift.CL_w = lift.CL_alpha_w*(alpha+cfg.geometry.wing_incidence_deg*pi/180);
tail_alpha = (1-lift.downwash_gradient)*alpha ...
    +cfg.geometry.tail_incidence_deg*pi/180-lift.tau_e*dele_up_deg*pi/180;
lift.CL_t = lift.CL_alpha_t*tail_alpha;
lift.CL_alpha_T = lift.CL_alpha_w+lift.Ettah*(g.SrefHt/g.SrefW) ...
    *lift.CL_alpha_t*(1-lift.downwash_gradient);
lift.CL_T = lift.CL_w+lift.Ettah*(g.SrefHt/g.SrefW)*lift.CL_t;
lift.valid_linear = abs(lift.CL_T)<=cfg.aero.CLmax ...
    & abs(lift.CL_t)<=cfg.aero.tail_CLmax;
end
