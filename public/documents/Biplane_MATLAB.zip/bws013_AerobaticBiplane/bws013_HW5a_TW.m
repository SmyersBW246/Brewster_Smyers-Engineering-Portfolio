function tw = bws013_HW5a_TW(cfg,g,mission)
% HW5a: shaft power, propeller thrust, stage T/W and physical margins.
% T=eta*550*P/V is used only at positive flight speeds. Ground-run thrust
% is capped by an actuator-disk static estimate; it cannot diverge at V=0.
atm0 = cfg.atmosphere(0);
N = numel(mission.names);
tw.V_TAS_fps = zeros(1,N); tw.V_EAS_kt=zeros(1,N);
tw.CL=zeros(1,N); tw.D=zeros(1,N); tw.L=zeros(1,N);
tw.T_req=zeros(1,N); tw.T_available=zeros(1,N);
tw.P_req_hp=zeros(1,N); tw.P_available_hp=zeros(1,N);
tw.power_margin_hp=NaN(1,N); tw.ROC_available_fpm=NaN(1,N);
tw.trim_alpha_deg=NaN(1,N); tw.trim_elevator_deg=NaN(1,N);
tw.static_margin=NaN(1,N); tw.stalled=false(1,N);
tw.sustained_required = mission.airborne;
tw.sustained_required(5)=false;        % high-g point is instantaneous
tw.atmosphere = cell(1,N);
for j=1:N
    a = cfg.atmosphere(mission.alt_eval_ft(j)); tw.atmosphere{j}=a;
    if ~mission.airborne(j), continue; end
    W = mission.weight_start_lb(j);   % conservative start weight for phase
    Vs_EAS = sqrt(2*W/(atm0.rho*g.SrefW*cfg.aero.CLmax))/cfg.units.kt_to_fps;
    speed = mission.speed_value_kt(j);
    if j==2, speed=1.2*Vs_EAS; end
    if j==8, speed=1.3*Vs_EAS; end
    if mission.speed_is_EAS(j)
        VEAS=speed*cfg.units.kt_to_fps;
        V=VEAS/sqrt(a.rho/atm0.rho);
    else
        V=speed*cfg.units.kt_to_fps; VEAS=V*sqrt(a.rho/atm0.rho);
    end
    tw.V_TAS_fps(j)=V; tw.V_EAS_kt(j)=VEAS/cfg.units.kt_to_fps;
    gamma = asind((mission.ROC_fpm(j)/60)/V);
    n = mission.load_factor(j);
    if j~=5, n=cosd(gamma); end % lift balances normal component in climb/descent
    d = bws013_HW11_Drag(cfg,g,W,V,a,n);
    tw.CL(j)=d.CL; tw.D(j)=d.D; tw.L(j)=d.L; tw.stalled(j)=d.stalled;
    eta=mission.eta_prop(j);
    tw.T_req(j)=d.D+W*sind(gamma);
    tw.P_req_hp(j)=tw.T_req(j)*V/(550*eta);
    lapse=interp1(cfg.engine.altitude_ft,cfg.engine.power_fraction, ...
        mission.alt_eval_ft(j),'linear');
    tw.P_available_hp(j)=min(mission.power_hp(j),cfg.engine.rated_hp*lapse);
    tw.T_available(j)=eta*550*tw.P_available_hp(j)/V;
    tw.power_margin_hp(j)=tw.P_available_hp(j)-tw.P_req_hp(j);
    tw.ROC_available_fpm(j)=60*(eta*550*tw.P_available_hp(j)-d.D*V)/W;
    s=bws013_HW13_StabControl(cfg,g,W,mission.fuel_start_gal(j),V/a.a_fps,d.CL);
    tw.trim_alpha_deg(j)=s.alpha_deg; tw.trim_elevator_deg(j)=s.dele_up_deg;
    tw.static_margin(j)=s.SM;
    tw.trim_valid(j)=s.trim_valid;
end
tw.TW_required=tw.T_req./mission.weight_start_lb;
tw.TW_available=tw.T_available./mission.weight_start_lb;
tw.TW_max=max(tw.TW_required(tw.sustained_required));
tw.Thrust_req=tw.TW_max*mission.takeoff_lb;

% Ground-run integration: acceleration includes wheel unloading and drag.
W=mission.takeoff_lb;
Vs=sqrt(2*W/(atm0.rho*g.SrefW*cfg.aero.CLmax));
tw.V_liftoff_fps=1.2*Vs;
v=linspace(0,tw.V_liftoff_fps,1001);
P=cfg.engine.rated_hp*550;
disk=pi*(cfg.prop.diameter_ft/2)^2;
tw.static_thrust_lb=(2*atm0.rho*disk*(cfg.prop.static_power_factor*P)^2)^(1/3);
% Forward-flight actuator disk: P_air=2*rho*A*vi*(V+vi)^2.
% A constant static-thrust cap alone overestimates thrust during the roll.
vi=ones(size(v))*(cfg.prop.static_power_factor*P/(2*atm0.rho*disk))^(1/3);
for k=1:20
    vi=vi-(vi.*(v+vi).^2-cfg.prop.static_power_factor*P/(2*atm0.rho*disk)) ...
        ./((v+vi).*(v+3*vi));
end
T=min(2*atm0.rho*disk*vi.*(v+vi),cfg.prop.eta_takeoff*P./max(v,1));
tw.groundrun_speed_fps=v; tw.groundrun_thrust_lb=T;
q=0.5*atm0.rho*v.^2;
CLg=cfg.ground.CL_ground_fraction*cfg.aero.CLmax;
baseline=bws013_HW11_Drag(cfg,g,W,max(0.7*tw.V_liftoff_fps,30),atm0,1);
L=min(q*g.SrefW*CLg,W);
D=q*g.SrefW*(baseline.CD0+cfg.ground.induced_factor*baseline.k*CLg^2);
acc=cfg.units.g_fps2/W*(T-D-cfg.ground.rolling_mu*(W-L));
assert(all(acc>0),'Nonpositive takeoff acceleration: mission cannot take off.');
tw.takeoff_groundroll_ft=trapz(v,v./acc);
tw.takeoff_groundtime_s=trapz(v,1./acc);
tw.groundrun_acceleration_fps2=acc;
tw.takeoff_over50_ft=tw.takeoff_groundroll_ft+50/tand(asind( ...
    (cfg.mission.climb_fpm/60)/tw.V_TAS_fps(3)));

% A high-g point can produce enough lift and still have an energy deficit.
tw.aerobatic_energy_loss_hp=max(-tw.power_margin_hp(5)*mission.eta_prop(5),0);
tw.aerobatic_specific_energy_rate_fps= ...
    -550*tw.aerobatic_energy_loss_hp/mission.weight_start_lb(5);
end
