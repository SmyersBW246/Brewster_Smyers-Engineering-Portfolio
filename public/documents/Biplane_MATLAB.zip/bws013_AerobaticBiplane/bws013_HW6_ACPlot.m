function bws013_HW6_ACPlot(cfg,g)
% HW6 aircraft plot: both rounded-tip wings, distinct planes and real tails.
% Uses base MATLAB graphics only. No ellipse.m, polyshape or toolbox needed.
figure('Name','HW6 - aerobatic biplane geometry','Color','w');
subplot(2,1,1); hold on;
xf=[g.fuse_x,fliplr(g.fuse_x)];
yf=[g.fuse_w/2,-fliplr(g.fuse_w/2)];
fill(xf,yf,[0.82,0.82,0.82],'FaceAlpha',0.6,'EdgeColor',[0.3,0.3,0.3]);
mid=g.x_lower_LE_ft+g.crW/2;
xwing=[mid-g.cW/2,fliplr(mid+g.cW/2)];
ywing=[g.yW,fliplr(g.yW)];
fill(xwing,ywing,[0.2,0.5,0.85],'FaceAlpha',0.30,'EdgeColor',[0.1,0.3,0.7]);
fill(xwing+g.stagger_aft_ft,ywing,[0.95,0.6,0.15], ...
    'FaceAlpha',0.30,'EdgeColor',[0.75,0.4,0.1]);
xt=[g.x_HT_LE_ft,g.x_HT_LE_ft,g.x_HT_LE_ft+g.ctHt, ...
    g.x_HT_LE_ft+g.crHt,g.x_HT_LE_ft+g.ctHt,g.x_HT_LE_ft,g.x_HT_LE_ft];
yt=[0,g.bHt/2,g.bHt/2,0,-g.bHt/2,-g.bHt/2,0];
fill(xt,yt,[0.3,0.7,0.4],'FaceAlpha',0.6);
plot([0,0],[-cfg.prop.diameter_ft/2,cfg.prop.diameter_ft/2],'k-','LineWidth',3);
plot(g.x_wing_ac_ft,0,'ro','MarkerFaceColor','r');
plot(g.x_HT_ac_ft,0,'ro','MarkerFaceColor','r');
axis equal; grid on; xlabel('x aft from spinner (ft)'); ylabel('Spanwise y (ft)');
title('Two-person aerobatic biplane: top view (upper wing orange)');
xlim([-1,g.L_fuse+1]); ylim([-g.bW/2-1,g.bW/2+1]);

subplot(2,1,2); hold on;
% Section center heights are conceptual; preserve hull sizes and CAD wing/tail.
zc=cfg.geometry.fuse_center_z_in/12;
fill([g.fuse_x,fliplr(g.fuse_x)], ...
    [zc+g.fuse_h/2,fliplr(zc-g.fuse_h/2)],[0.82,0.82,0.82]);
plot([g.x_lower_LE_ft,g.x_lower_LE_ft+g.crW], ...
    [g.z_lower_ft,g.z_lower_ft],'b-','LineWidth',4);
plot([g.x_lower_LE_ft,g.x_lower_LE_ft+g.crW]+g.stagger_aft_ft, ...
    [g.z_lower_ft,g.z_lower_ft]+g.gap_ft,'Color',[0.9,0.5,0.1],'LineWidth',4);
plot([g.x_HT_LE_ft,g.x_HT_LE_ft+g.crHt],[g.z_HT_ft,g.z_HT_ft], ...
    'Color',[0.1,0.6,0.2],'LineWidth',4);
xv=[g.x_VT_LE_ft,g.x_VT_LE_ft+g.bVt*tand(g.Vtsweep), ...
    g.x_VT_LE_ft+g.bVt*tand(g.Vtsweep)+g.ctVt,g.x_VT_LE_ft+g.crVt];
zv=[g.z_HT_ft,g.z_HT_ft+g.bVt,g.z_HT_ft+g.bVt,g.z_HT_ft];
fill(xv,zv,[0.3,0.7,0.4],'FaceAlpha',0.6);
for j=1:2
    x=g.x_lower_LE_ft+g.crW*[0.25,0.75];
    plot([x(j),x(j)+g.stagger_aft_ft],[g.z_lower_ft,g.z_lower_ft+g.gap_ft],'k-');
end
axis equal; grid on; xlabel('x aft from spinner (ft)'); ylabel('Height z (ft)');
title(sprintf('Side view; gap %.2f ft, upper stagger %.2f ft aft, tail arm %.2f ft', ...
    g.gap_ft,g.stagger_aft_ft,g.t_arm));
xlim([-1,g.L_fuse+1]);
end
