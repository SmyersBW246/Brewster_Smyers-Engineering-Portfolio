function drag = bws013_HW11_Drag(cfg,g,W_lb,V_TAS_fps,atm,load_factor)
% HW11: low-subsonic, component parasite buildup plus whole-aircraft polar.
% mu is DYNAMIC viscosity, slug/(ft s). V is TAS, ft/s, never Mach or IAS.
% Cooling, gear and bracing replace the old twin-nacelle terms.
% Effective e_ref includes biplane/trim losses: do not add those losses twice.
if nargin<6, load_factor=1; end
assert(V_TAS_fps>0 && atm.rho>0 && W_lb>0,'Drag inputs must be positive.');
drag.V_TAS_fps = V_TAS_fps;
drag.Mach = V_TAS_fps/atm.a_fps;
assert(drag.Mach<0.4,'This conceptual polar is limited to Mach < 0.4.');
drag.q = 0.5*atm.rho*V_TAS_fps^2;
drag.CL = load_factor*W_lb/(drag.q*g.SrefW);
drag.Re_wing = atm.rho*V_TAS_fps*g.cbarW/atm.mu;

% Conservative fully turbulent friction for fabric/rough surfaces. No
% unsupported 65% laminar-flow credit is carried over from the old files.
lengths = [g.cbarW,g.cbarHt,g.cbarVt,g.L_fuse,cfg.geometry.strut_chord_ft];
Re = atm.rho*V_TAS_fps*lengths/atm.mu;
assert(all(Re>1e4),'Reynolds number outside component buildup range.');
Cf = 0.455./(log10(Re).^2.58*(1+0.144*drag.Mach^2)^0.65);
tc = cfg.aero.thickness_ratio;
FFsurface = 1+0.6/0.3*tc+100*tc^4;
fineness = g.L_fuse/g.d_fuse_eq_ft;
FFfuse = 1+60/fineness^3+fineness/400;
FFstrut = 1.5;                     % conceptual streamlined-strut estimate
FF = [FFsurface,FFsurface,FFsurface,FFfuse,FFstrut];
Q = [1.15,1.08,1.08,1.05,1.20];   % assumed junction factors
Swet = [g.Swet_wing,g.Swet_Htail,g.Swet_Vtail,g.Swet_fuse,g.Swet_struts];
drag.component_names = {'Both wings','Horizontal tail','Vertical tail','Fuselage/cowl','Struts'};
drag.component_flatplate_ft2 = Cf.*FF.*Q.*Swet;
drag.misc_flatplate_ft2 = cfg.aero.misc_flatplate_ft2;
drag.flatplate_ft2 = sum(drag.component_flatplate_ft2)+drag.misc_flatplate_ft2;
drag.CD0 = drag.flatplate_ft2/g.SrefW;
drag.k = 1/(pi*cfg.aero.e_ref*g.AR_ref);
drag.CDi = drag.k*drag.CL^2;
drag.CDT = drag.CD0+drag.CDi;
drag.DP = drag.q*g.SrefW*drag.CD0;
drag.DL = drag.q*g.SrefW*drag.CDi;
drag.D = drag.DP+drag.DL;
drag.L = drag.q*g.SrefW*drag.CL;
drag.stalled = abs(drag.CL)>cfg.aero.CLmax;
drag.LD = abs(drag.L)/drag.D;
drag.power_propulsive_hp = drag.D*V_TAS_fps/550;
end
