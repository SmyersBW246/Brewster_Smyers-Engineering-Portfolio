function Results = bws013_AerobaticBiplane_wrapper(makePlots,verbose,overrides)
% BWS013_AEROBATICBIPLANE_WRAPPER  Fresh two-person aerobatic biplane analysis.
%
% RUN: extract all 11 files together, set MATLAB's Current Folder there, then
%   R = bws013_AerobaticBiplane_wrapper;             % results + all plots
%   R = bws013_AerobaticBiplane_wrapper(false);      % calculations only
%   R = bws013_AerobaticBiplane_wrapper(false,false);% quiet verification
% Optional third argument recursively overrides inputs for design studies.
% No Aerospace Toolbox, Optimization Toolbox, external ellipse.m, or web
% connection is needed. Functions return named structures; numeric results
% are in R.Mission, R.Airfoil, R.TW, R.WS, R.Geometry, R.Cruise, R.Stability.
%
% RETROFIT / RESEARCH AUDIT (28 October 2026)
% The supplied set has HW2 onward; no separate HW1 file was supplied. This
% wrapper contains the design brief/mission setup and preserves all nine HW
% module roles. Every mgo005 function/file becomes bws013. NACA2412 data is
% replaced by explicitly analytical NACA0012 teaching data, not relabeled.
%
% Retained from prior biplane work and independently supported by Aviat [1]:
%   span 20 ft; TOTAL wing area 127.5 ft2; length 213 in; 260 hp;
%   reference empty weight 1155 lb; normal usable fuel 28 gal;
%   clean stall reference 56 KIAS; cruise reference 150 KTAS at 75% power.
% Retained as PROJECT GEOMETRY, not measured production Pitts dimensions:
%   HT root/tip 30/26.28 in, half-span 49.25 in; VT 45/21.38 in,
%   height 46.6 in; gap 45 in; 6 in stagger. The latest drawing says upper
%   wing AFT, whereas the older report said forward. Aft is explicit here.
%   Recent HT coordinate files take precedence over the older 114 in arm:
%   root LE/TE x=113/143 in relative to lower LE; CAD y=-35.5 in.
%   The arm is DERIVED from those locations and actual MACs, about 107 in.
%   Those fixed CAD tail/wing elevations give 80.1 in overall height versus
%   Aviat's 77 in. This 4% geometry difference is reported, not hidden.
%   Plane/oval intersection coordinates are CAD construction constraints;
%   the aerodynamic program needs areas, MAC/AC locations and wetted-area
%   estimates rather than every spline control point. Hull estimates below
%   come from the earlier station guide, not a new exact SolidWorks surface.
%
% Corrected after research/review:
%   OLD 1625 lb aerobatic limit -> 1700 lb for S-2C, FAA TCDS [2], p9.
%   1625 is S-2B; Aviat's marketing table mixes some category loading values.
%   OLD 35-40 kt stall target -> 56 kt gross reference. Code quantifies the
%   much larger wing area needed for 35/40 kt; it does not claim both targets.
%   OLD 300-mile + aerobatics mission -> local 30 nm out / 30 nm back sortie.
%   Fuel-limited cross-country range is reported separately, with reserves.
%   OLD taxi/takeoff at 30% power -> separate ground and full-power phases.
%   OLD universal 0.43077 BSFC -> phase-specific rich/high-power fuel flows.
%   OLD reserve burned before landing -> protected fuel still aboard at end.
%   OLD cruise 6000 ft -> local sortie 3000 ft to avoid unbudgeted descents/
%   re-climbs; a separate 6000 ft published-cruise comparison remains.
%   OLD two 180 lb occupants -> same occupants PLUS 15 lb worn gear each.
%   OLD fixed 5% static margin -> calculated CG/NP at every mission weight.
%   OLD upper/lower area ambiguity, nacelles, tail AR=wing AR, Mach=constant
%   sea-level sound speed, elevator sign, and hard-coded trim annotations
%   are removed. Lift/drag/CG/power now share the same weights and geometry.
%
% INPUT CLASSIFICATION:
% Published [P]: aircraft scale, engine, limits, reference performance/fuel.
% Derived [D]: atmosphere, MAC/areas/arms, Reynolds number, CLmax, weights.
% Assumed [A]: mission, equal wing split, gap/stagger, CG budget, tail
% efficiency/downwash, e=0.70, component wetted estimates, propeller map.
% Calibrated [C]: CD0=0.033 at 150 KTAS/6000 ft, retained from the earlier
% concept. Its residual flat-plate area represents gear, wires, cooling and
% miscellaneous losses. Matching a calibration input is NOT validation.
%
% Sources (primary documents; URLs and page references are retained below):
% [1] Aviat Pitts S-2C specifications/performance.
% https://aviataircraft.com/fusion_element/pitts-specs/
% https://aviataircraft.com/aviat-aircraft-pitts/
% [2] FAA TCDS A8SO rev21, S-2C pp9-10; empty/unusable fuel p11.
% https://pittss2b.com/a8sopitts.pdf (FAA document hosted by owner group).
% [3] Lycoming 60297-21, AEIO engine operator manual, printed pp4-9, 9-4:
% 260 hp full-power 21.6 gph; 195 hp rich 19.0 gph. Manufacturer's leaned
% cruise 14 gph is a different mixture condition, not contradictory physics.
% https://www.lycoming.com/sites/default/files/attachments/AEIO-320-360-540%2520Oper%2520Manual%252060297-21.pdf
% [4] NASA NACA TR151: gap/stagger/decalage and biplane interference.
% https://ntrs.nasa.gov/citations/19930091216
% [5] NASA induced-drag/reference-area equations:
% https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/induced-drag-coefficient/
% [6] U.S. Standard Atmosphere 1976:
% https://ntrs.nasa.gov/citations/19770009539
%
% Scope: conceptual homework analysis, not aircraft operating instructions.
% No measured CG, propeller map, biplane CFD, spin recovery, structural proof,
% or flight-test polar was provided. The program identifies those estimates
% rather than presenting calculated values as measured production data.
% Verification record for this release: GNU Octave 8.4.0 execution, 30 built-in
% checks, 11 regression/integration cases, independent Python fuel/mass/area
% ledger, and 9 rendered plots. MATLAB itself was not available for execution.

if nargin<1, makePlots=true; end
if nargin<2, verbose=true; end
if nargin<3, overrides=struct(); end
addpath(fileparts(mfilename('fullpath')));

%% Design brief / HW1 inputs (all editable aircraft inputs in this block)
cfg.units.kt_to_fps = 1852/3600/0.3048;
cfg.units.g_fps2 = 9.80665/0.3048;
cfg.atmosphere = @isaAtmosphere;
cfg.mass.empty_lb = 1155;                    % [P] incl. unusable fuel
cfg.mass.max_normal_lb = 1700;               % [P] TCDS S-2C
cfg.mass.max_aerobatic_lb = 1700;            % [P] NOT S-2B's 1625
cfg.mass.occupants_lb = [180,180];           % [A] two people
cfg.mass.worn_equipment_lb = [15,15];        % [A] gear allowance per seat
cfg.mass.baggage_lb = 0;
cfg.mass.empty_cg_x_ft = 76.5/12;            % [A] replace with CAD mass CG
cfg.mass.seat_x_ft = [84,133]/12;            % [A] earlier CAD cockpits
cfg.mass.baggage_x_ft = 156/12;
cfg.mass.main_fuel_x_ft = 61/12;             % [A] conceptual fuselage tank
cfg.engine.rated_hp = 260;                   % [P] AEIO-540-D4A5 class
cfg.engine.altitude_ft = [0,500,1000,2000,2500,3000,4000,5000,6000,7000,8000,9000,10000];
cfg.engine.power_fraction = [1,.985,.968,.936,.920,.905,.875,.846,.817,.789,.762,.735,.708]; % [P] Lycoming altitude table
cfg.prop.diameter_ft = 76/12;                % [P] current Aviat prop proxy
cfg.prop.eta_takeoff = 0.65;                 % [A]
cfg.prop.static_power_factor = 0.60;         % [A] static actuator-disk proxy
cfg.prop.eta_cruise = 0.80;                  % [A]
cfg.prop.eta_highspeed = 0.82;               % [A], not fitted to max speed
cfg.prop.eta_climb = 0.75;
cfg.prop.eta_aerobatic = 0.75;
cfg.prop.eta_descent = 0.75;
cfg.prop.eta_approach = 0.65;

cfg.geometry.S_total_ft2 = 127.5;            % [P] BOTH wings together
cfg.geometry.span_ft = 20;
cfg.geometry.length_ft = 213/12;
cfg.geometry.gap_ft = 45/12;                 % [A] prior CAD rigging
cfg.geometry.stagger_aft_ft = 6/12;          % [A] upper wing AFT
cfg.geometry.lower_LE_x_ft = 64/12;          % [A] spinner datum
cfg.geometry.lower_z_ft = 24/12;
cfg.geometry.HT_halfspan_in = 49.25;          % prior accepted CAD
cfg.geometry.HT_root_in = 30;
cfg.geometry.HT_tip_in = 26.28;
cfg.geometry.HT_LE_from_lower_in = 113;
cfg.geometry.HT_above_lower_in = 9.5;        % CAD y=-35.5 minus (-45)
cfg.geometry.VT_height_in = 46.6;
cfg.geometry.VT_root_in = 45;
cfg.geometry.VT_tip_in = 21.38;
cfg.geometry.VT_LE_sweep_deg = 22.29;
cfg.geometry.VT_LE_from_lower_in = 98;
cfg.geometry.wing_incidence_deg = 0;
cfg.geometry.tail_incidence_deg = 0;
cfg.geometry.fuse_station_in = [0,10,32,64,84,109,133,156,180,202,213];
cfg.geometry.fuse_width_in = [0,20,26,28,28,27,24,17,10,5,2];
cfg.geometry.fuse_height_in = [0,22,29,32,35,37,31,17,11,7,3];
cfg.geometry.fuse_center_z_in = [38,38,38,36,35.5,35.5,35.5,35,35,35,35];
cfg.geometry.cabane_length_ft = 3.5;
cfg.geometry.strut_chord_ft = 2.5/12;

cfg.aero.e_ref = 0.70;                       % [A] effective biplane e
cfg.aero.e_tail = 0.85;
cfg.aero.thickness_ratio = 0.12;             % [A] representative NACA0012
cfg.aero.tail_q_ratio = 0.90;
cfg.aero.downwash_gradient = 0.35;           % [A] d epsilon / d alpha
cfg.aero.tail_CLmax = 1.2;
cfg.aero.Cm0 = 0;                           % symmetric section assumption
cfg.aero.Cm_alpha_fuselage = 0.10;           % [A] destabilizing, per radian
cfg.aero.CD0_target = 0.0330;                % [C] reference point only
cfg.aero.misc_flatplate_ft2 = 0;             % solved after surface buildup
cfg.controls.elevator_chord_ratio = 0.40;    % prior CAD 60%-chord hinge
cfg.controls.elevator_limit_deg = 25;        % [A] conservative travel
cfg.controls.min_static_margin = 0.03;       % conceptual screening minimum

cfg.fuel.density_lb_gal = 6.0;               % [A] avgas sizing convention
cfg.fuel.main_usable_gal = 23;               % 24 total minus 1 unusable
cfg.fuel.normal_usable_gal = 28;             % [P] includes 5-gal wing tank
cfg.fuel.wing_loaded_gal = 0;                % empty for aerobatics
cfg.fuel.reserve_min = 30;                  % protected, not a flown phase
cfg.fuel.reserve_flow_gph = 14;             % normal cruise, not idle/loiter
cfg.fuel.contingency_fraction = 0.05;        % [A] of trip burn
cfg.fuel.dispatch_usable_gal = 0;            % 0 = calculate required fuel
% Flows: taxi, takeoff, climb, outbound, aerobatics, return, descent,
% approach/landing, taxi in. Taxi=4 [A]; takeoff/climb=21.6 [P] rich;
% cruise=14 [P benchmark/A budget at lower power]; aerobatics=19.5 [A],
% conservatively above Lycoming 19 gph at ~195 hp; descent=8 [A];
% approach=10 [A]. Do not extrapolate lean-cruise BSFC to rich phases.
cfg.fuel.phase_flow_gph = [4,21.6,21.6,14,19.5,14,8,10,4];
cfg.mission.distance_each_nm = 30;
cfg.mission.cruise_TAS_kt = 130;
cfg.mission.altitude_ft = 3000;              % same cruise/practice altitude
cfg.mission.climb_fpm = 1200;                % scheduled, not max ROC
cfg.mission.descent_fpm = 750;
cfg.mission.aerobatic_min = 15;
cfg.mission.aerobatic_EAS_kt = 120;
cfg.mission.aerobatic_g = 4;                 % transient lift check
cfg.mission.aerobatic_cycle_s = 30;          % [A] illustrative energy-check cycle
cfg.mission.aerobatic_pulse_s = 1.5;         % high-g pulse, then recovery
cfg.mission.aerobatic_recovery_EAS_kt = 130;  % entry/exit energy-check speed
cfg.mission.climb_fraction_of_available_power = 0.95;
cfg.mission.aerobatic_fraction_of_available_power = 0.85;
cfg.mission.cruise_fraction_of_rated_power = 0.65;
cfg.mission.taxi_fraction_of_rated_power = 0.10;
cfg.mission.descent_fraction_of_rated_power = 0.25;
cfg.mission.approach_fraction_of_rated_power = 0.30;
cfg.mission.headwind_kt = 0;                 % outbound headwind, return tailwind
cfg.mission.taxi_out_min = 8;
cfg.mission.takeoff_min = 1;
cfg.mission.approach_min = 4;
cfg.mission.taxi_in_min = 3;
cfg.ground.rolling_mu = 0.025;
cfg.ground.braking_mu = 0.30;
cfg.ground.induced_factor = 0.7;             % approximate ground effect
cfg.ground.CL_ground_fraction = 0.5;
cfg.ground.approach_angle_deg = 3;
cfg.requirements.stall_EAS_kt = 56;
cfg.requirements.approach_EAS_kt = 75;
cfg.requirements.takeoff_groundroll_ft = 800;
cfg.requirements.landing_over50_ft = 1800;
cfg.reference.stall_EAS_kt = 56;             % 56 KIAS approximated as EAS
cfg.reference.cruise_TAS_kt = 150;
cfg.reference.cruise_altitude_ft = 6000;
cfg.reference.cruise_flow_gph = 14;
cfg.reference.maximum_level_kt = 169;
cfg.reference.ROC_minweight_fpm = 2900;
cfg.reference.takeoff_groundroll_ft = 554;
cfg.reference.landing_over50_ft = 1200;
cfg.reference.n_positive = 6;
cfg.reference.n_negative = -5;
cfg.reference.VA_EAS_kt = 134;
cfg.reference.VNO_EAS_kt = 134;
cfg.reference.VNE_EAS_kt = 184;               % TCDS CAS ~ EAS at low Mach
cfg.reference.height_in = 77;
cfg.reference.gross_lb = 1700;
cfg.reference.S_total_ft2 = 127.5;
cfg = mergeInputs(cfg,overrides);
assert(cfg.mission.altitude_ft>1000 && cfg.mission.altitude_ft<=10000,'Mission altitude must be 1000-10000 ft.');
assert(cfg.aero.e_ref>0 && cfg.aero.e_ref<=1,'Invalid effective e.');

%% Geometry initialization: published layout inputs, not wing-area resizing
g = bws013_HW6_WingTailDesign(cfg);
a0 = cfg.atmosphere(0);
cfg.aero.CLmax = 2*cfg.reference.gross_lb/(a0.rho*cfg.reference.S_total_ft2 ...
    *(cfg.reference.stall_EAS_kt*cfg.units.kt_to_fps)^2);
% Component drag closure at one reference condition. All residual drag is
% visible; no two engine nacelles and no separate hidden CD0 offset.
aref = cfg.atmosphere(cfg.reference.cruise_altitude_ft);
raw = bws013_HW11_Drag(cfg,g,cfg.mass.max_normal_lb, ...
    cfg.reference.cruise_TAS_kt*cfg.units.kt_to_fps,aref,1);
cfg.aero.misc_flatplate_ft2 = cfg.aero.CD0_target*g.SrefW-sum(raw.component_flatplate_ft2);
assert(cfg.aero.misc_flatplate_ft2>=0,'Drag calibration would require negative miscellaneous drag.');

%% HW2 -> HW3 -> HW5a -> HW5b -> HW6 -> HW11 -> HW12 -> HW13
m = bws013_HW2_AircraftSizing(cfg);
af = bws013_HW3_AirfoilPlots(cfg,g,m,makePlots);
tw = bws013_HW5a_TW(cfg,g,m);
ws = bws013_HW5b_WS(cfg,g,m,tw);
if makePlots, bws013_HW6_ACPlot(cfg,g); end
ac = cfg.atmosphere(cfg.mission.altitude_ft);
Vc = cfg.mission.cruise_TAS_kt*cfg.units.kt_to_fps;
cruise = bws013_HW11_Drag(cfg,g,m.weight_start_lb(4),Vc,ac,1);
stability = bws013_HW13_StabControl(cfg,g,m.weight_start_lb(4), ...
    m.fuel_start_gal(4),Vc/ac.a_fps,cruise.CL);
lf = bws013_HW12_Lift(cfg,g,Vc/ac.a_fps,stability.alpha_deg,stability.dele_up_deg);
cruise.alpha_deg = stability.alpha_deg;
cruise.dele_up_deg = stability.dele_up_deg;
cruise.LDmax_local = 1/(2*sqrt(cruise.CD0*cruise.k));
cruise.CL_at_LDmax = sqrt(cruise.CD0/cruise.k);

Results.cfg=cfg; Results.Geometry=g; Results.Mission=m; Results.Airfoil=af;
Results.TW=tw; Results.WS=ws; Results.Cruise=cruise;
Results.Lift=lf; Results.Stability=stability;
Results.AerobaticEnergy=aerobaticEnergyCheck(cfg,g,m);
Results.Benchmark=benchmarkPerformance(cfg,g,m);
Results.Validation=validateModel(Results);
if verbose, printResults(Results); end
if makePlots, makeAnalysisPlots(Results); end
end

function a=isaAtmosphere(h_ft)
% Tropospheric geopotential-altitude ISA, with Sutherland dynamic viscosity.
assert(isscalar(h_ft) && h_ft>=0 && h_ft<=36089,'ISA altitude outside troposphere.');
h=h_ft*0.3048; T=288.15-0.0065*h;
p=101325*(T/288.15)^(9.80665/(287.05287*0.0065));
a.rho=(p/(287.05287*T))/515.378818;
a.mu=(1.7894e-5*(T/288.15)^1.5*(288.15+110.4)/(T+110.4))/47.88025898;
a.a_fps=sqrt(1.4*287.05287*T)/0.3048;
a.T_K=T; a.p_Pa=p; a.altitude_ft=h_ft;
end

function cfg=mergeInputs(cfg,updates)
assert(isstruct(updates),'Overrides must be a structure.');
names=fieldnames(updates);
for j=1:numel(names)
    n=names{j}; assert(isfield(cfg,n),['Unknown input: ',n]);
    if isstruct(updates.(n)), cfg.(n)=mergeInputs(cfg.(n),updates.(n));
    else, cfg.(n)=updates.(n); end
end
end

function e=aerobaticEnergyCheck(cfg,g,m)
% An illustrative level, banked high-g pulse followed by 1-g acceleration.
% Integrates specific kinetic energy, so high-g drag cannot be sustained by
% merely labeling a negative power margin 'transient'. A complete periodic
% cycle must regain entry speed using the budgeted engine power, within the
% allocated time, without exceeding CLmax. This is NOT a six-DOF flight path
% or a prescription for an actual aerobatic maneuver. Fixed entry weight
% conservatively bounds the induced drag of later, lighter cycles.
W=m.weight_start_lb(5); a=cfg.atmosphere(cfg.mission.altitude_ft);
a0=cfg.atmosphere(0); eta=m.eta_prop(5); Pmax=m.power_hp(5);
targetV=cfg.mission.aerobatic_recovery_EAS_kt*cfg.units.kt_to_fps/sqrt(a.rho/a0.rho);
assert(cfg.mission.aerobatic_recovery_EAS_kt<=cfg.reference.VA_EAS_kt, ...
    'Energy-check entry speed exceeds maneuvering-speed proxy.');
period=cfg.mission.aerobatic_cycle_s; pulse=cfg.mission.aerobatic_pulse_s;
assert(pulse>0 && pulse<period,'High-g pulse must be shorter than the cycle.');
steps=ceil(period/0.05); dt=period/steps;
e.time_s=(0:steps)*dt;
e.specific_energy_ft=zeros(1,steps+1);
e.specific_energy_ft(1)=targetV^2/(2*cfg.units.g_fps2);
targetE=e.specific_energy_ft(1);
e.CL=zeros(1,steps); e.power_hp=zeros(1,steps); e.load_factor=zeros(1,steps);
e.energy_rate_fps=zeros(1,steps); recovery=NaN;
for k=1:steps
    V=sqrt(2*cfg.units.g_fps2*e.specific_energy_ft(k));
    inPulse=(e.time_s(k)<pulse-1e-10);
    n=1; if inPulse, n=cfg.mission.aerobatic_g; end
    d=bws013_HW11_Drag(cfg,g,W,V,a,n);
    P=Pmax;
    if ~inPulse
        % Reduce throttle at target energy; no artificial speed/energy reset.
        P=min(Pmax,max(((targetE-e.specific_energy_ft(k))/dt*W+d.D*V)/(550*eta),0));
    end
    rate=(eta*550*P-d.D*V)/W;
    e.specific_energy_ft(k+1)=e.specific_energy_ft(k)+dt*rate;
    assert(e.specific_energy_ft(k+1)>0,'Aerobatic cycle exhausted kinetic energy.');
    Vend=sqrt(2*cfg.units.g_fps2*e.specific_energy_ft(k+1));
    endCL=n*W/(0.5*a.rho*Vend^2*g.SrefW);
    e.CL(k)=max(d.CL,endCL); e.power_hp(k)=P;
    e.load_factor(k)=n; e.energy_rate_fps(k)=rate;
    if ~inPulse && isnan(recovery) && e.specific_energy_ft(k+1)>=targetE-1e-8
        recovery=e.time_s(k+1)-pulse;
    end
end
e.V_EAS_kt=sqrt(2*cfg.units.g_fps2*e.specific_energy_ft)*sqrt(a.rho/a0.rho)/cfg.units.kt_to_fps;
e.minimum_EAS_kt=min(e.V_EAS_kt);
e.maximum_CL=max(e.CL);
e.recovery_time_s=recovery;
e.average_power_hp=mean(e.power_hp);
e.final_energy_error_ft=e.specific_energy_ft(end)-targetE;
e.integration_balance_error_ft=sum(e.energy_rate_fps)*dt-e.final_energy_error_ft;
e.complete_cycles=cfg.mission.aerobatic_min*60/period;
e.valid=~isnan(recovery) && e.maximum_CL<=cfg.aero.CLmax ...
    && abs(e.final_energy_error_ft)<1e-6 && abs(e.integration_balance_error_ft)<1e-6;
assert(abs(e.complete_cycles-round(e.complete_cycles))<1e-8, ...
    'Aerobatic duration must contain complete energy-check cycles.');
end

function b=benchmarkPerformance(cfg,g,m)
% Comparisons use their own altitude/power, not the local mission conditions.
a=cfg.atmosphere(cfg.reference.cruise_altitude_ft);
W=cfg.mass.max_normal_lb;
P75=0.75*cfg.engine.rated_hp;
b.cruise75_TAS_kt=fzero(@(v) levelPower(v,cfg,g,W,a,cfg.prop.eta_cruise)-P75,[110,180]);
a0=cfg.atmosphere(0);
b.maximum_SL_kt=fzero(@(v) levelPower(v,cfg,g,W,a0,cfg.prop.eta_highspeed) ...
    -cfg.engine.rated_hp,[110,185]);
d=bws013_HW11_Drag(cfg,g,m.takeoff_lb,82*cfg.units.kt_to_fps,a0,1);
b.ROC_SL_missionweight_fpm=60*(cfg.prop.eta_climb*550*cfg.engine.rated_hp-d.D*82*cfg.units.kt_to_fps)/m.takeoff_lb;
b.ROC_reference_is_minimum_weight=true; % no spurious same-condition error %
b.cruise_percent_difference=100*(b.cruise75_TAS_kt/cfg.reference.cruise_TAS_kt-1);
b.maximum_percent_difference=100*(b.maximum_SL_kt/cfg.reference.maximum_level_kt-1);

% A separate cross-country budget, no aerobatics. Includes taxi, takeoff,
% climb to 6000 ft, descent, approach, taxi in, contingency and protected
% 30-min NORMAL-CRUISE reserve. Climb/descent distance is not credited.
other=cfg.mission.taxi_out_min/60*cfg.fuel.phase_flow_gph(1) ...
    +cfg.mission.takeoff_min/60*cfg.fuel.phase_flow_gph(2) ...
    +(cfg.reference.cruise_altitude_ft-50)/cfg.mission.climb_fpm/60*cfg.fuel.phase_flow_gph(3) ...
    +(cfg.reference.cruise_altitude_ft-1000)/cfg.mission.descent_fpm/60*cfg.fuel.phase_flow_gph(7) ...
    +cfg.mission.approach_min/60*cfg.fuel.phase_flow_gph(8) ...
    +cfg.mission.taxi_in_min/60*cfg.fuel.phase_flow_gph(9);
b.ferry_noncruise_gal=other;
b.ferry_payload_limited_fuel_gal=min(cfg.fuel.normal_usable_gal, ...
    (cfg.mass.max_normal_lb-m.dry_loaded_lb)/cfg.fuel.density_lb_gal);
cruiseFuel=max((b.ferry_payload_limited_fuel_gal-m.reserve_gal) ...
    /(1+cfg.fuel.contingency_fraction)-other,0);
b.ferry_cruise_range_nm=cruiseFuel/cfg.reference.cruise_flow_gph*cfg.reference.cruise_TAS_kt;
b.ferry_cruise_range_statute_mi=b.ferry_cruise_range_nm*1852/1609.344;
b.fuel_for_300_statute_mi_gal=(300*1609.344/1852/cfg.reference.cruise_TAS_kt ...
    *cfg.reference.cruise_flow_gph+other)*(1+cfg.fuel.contingency_fraction)+m.reserve_gal;
b.fullfuel_payload_limit_lb=cfg.mass.max_normal_lb-cfg.mass.empty_lb ...
    -cfg.fuel.normal_usable_gal*cfg.fuel.density_lb_gal;
end

function P=levelPower(v_kt,cfg,g,W,a,eta)
d=bws013_HW11_Drag(cfg,g,W,v_kt*cfg.units.kt_to_fps,a,1);
P=d.power_propulsive_hp/eta;
end

function checks=validateModel(R)
cfg=R.cfg; g=R.Geometry; m=R.Mission; tw=R.TW; ws=R.WS;
labels={}; values=[];
labels{end+1}='Fuel mass conservation';
values(end+1)=abs(m.ramp_lb-m.final_lb-sum(m.burn_lb))<1e-7;
labels{end+1}='Reserve retained after taxi in';
values(end+1)=m.fuel_end_gal(end)>=m.reserve_gal-1e-8;
labels{end+1}='Main-tank capacity and empty wing tank';
values(end+1)=m.dispatch_gal<=cfg.fuel.main_usable_gal && cfg.fuel.wing_loaded_gal==0;
labels{end+1}='Ramp and takeoff gross-weight limits';
values(end+1)=m.ramp_lb<=cfg.mass.max_normal_lb && m.takeoff_lb<=cfg.mass.max_normal_lb;
labels{end+1}='Aerobatic entry gross-weight limit';
values(end+1)=m.weight_start_lb(5)<=cfg.mass.max_aerobatic_lb;
labels{end+1}='All phase fuel fractions physical';
values(end+1)=all(m.fraction>0 & m.fraction<1);
labels{end+1}='Grouped fractions equal actual final/ramp weight';
fractions=[m.W1_W0,m.W2_W1,m.W3_W2,m.W4_W3,m.W5_W4,m.W6_W5,m.W7_W6];
values(end+1)=abs(prod(fractions)-m.final_lb/m.ramp_lb)<1e-12;
labels{end+1}='Both-wing area and outline integration agree';
values(end+1)=abs(2*trapz(g.yW,g.cW)-g.SrefW)<0.002;
labels{end+1}='Single-wing and total reference aspect ratios';
values(end+1)=abs(g.AR_each-2*g.AR_ref)<1e-12;
labels{end+1}='Gross stall calibration closes';
a0=cfg.atmosphere(0);
calibStall=sqrt(2*cfg.reference.gross_lb/(a0.rho*cfg.reference.S_total_ft2*cfg.aero.CLmax))/cfg.units.kt_to_fps;
values(end+1)=abs(calibStall-cfg.reference.stall_EAS_kt)<1e-8;
labels{end+1}='Installed wing meets actual design constraints';
values(end+1)=ws.area_margin_ft2>=-1e-7;
labels{end+1}='Takeoff acceleration and ground-roll requirement';
values(end+1)=tw.takeoff_groundroll_ft<=cfg.requirements.takeoff_groundroll_ft;
labels{end+1}='Takeoff phase fuel time covers ground-run duration';
values(end+1)=tw.takeoff_groundtime_s<cfg.mission.takeoff_min*60;
labels{end+1}='Landing over-50-ft design requirement';
values(end+1)=ws.landing_over50_ft<=cfg.requirements.landing_over50_ft;
labels{end+1}='Every airborne point below lift limit';
values(end+1)=~any(tw.stalled(m.airborne));
labels{end+1}='Sustained phases have positive power margin';
values(end+1)=all(tw.power_margin_hp(tw.sustained_required)>=-1e-7);
labels{end+1}='Scheduled climb rate available at top of climb';
values(end+1)=tw.ROC_available_fpm(3)>=cfg.mission.climb_fpm;
labels{end+1}='Representative aerobatic load within structure limit';
values(end+1)=cfg.mission.aerobatic_g<=cfg.reference.n_positive;
labels{end+1}='Cruise lift and pitching-moment trim close';
values(end+1)=abs(R.Stability.CL_T-R.Cruise.CL)<1e-9 && abs(R.Stability.Cmcg)<1e-10;
labels{end+1}='Neutral point agrees with moment derivative';
values(end+1)=abs(R.Stability.slope_identity_error)<1e-10;
labels{end+1}='Up elevator has positive nose-up moment derivative';
values(end+1)=R.Stability.dCm_ddele_up_per_rad>0;
labels{end+1}='All airborne trims within elevator and lift limits';
values(end+1)=all(tw.trim_valid(m.airborne));
% Calculate CG at every phase END as well, so forward-tank burn cannot hide
% a late-flight stability problem. Reserve is still present in these weights.
SMend=zeros(1,numel(m.names));
for j=1:numel(m.names)
    s=bws013_HW13_StabControl(cfg,g,m.weight_end_lb(j),m.fuel_end_gal(j),0.15,0.25);
    SMend(j)=s.SM;
end
labels{end+1}='CG budget stable through all phase end weights';
values(end+1)=all(SMend>=cfg.controls.min_static_margin);
labels{end+1}='Mission cruise below structural cruise speed proxy';
values(end+1)=max(tw.V_EAS_kt([4,6]))<=cfg.reference.VNO_EAS_kt;
labels{end+1}='Phase power does not exceed altitude-lapsed engine';
pmax=cfg.engine.rated_hp*interp1(cfg.engine.altitude_ft,cfg.engine.power_fraction,m.alt_eval_ft);
values(end+1)=all(tw.P_available_hp(m.airborne)<=pmax(m.airborne)+1e-8);
labels{end+1}='Steady-flight fuel budget covers minimum BSFC';
ix=tw.sustained_required;
values(end+1)=all(m.flow_gph(ix)*cfg.fuel.density_lb_gal>=0.43*tw.P_req_hp(ix));
labels{end+1}='Cruise component drag and total drag close';
values(end+1)=abs(R.Cruise.D-R.Cruise.DP-R.Cruise.DL)<1e-8;
labels{end+1}='Reference parasite calibration exposed and nonnegative';
a=cfg.atmosphere(cfg.reference.cruise_altitude_ft);
d=bws013_HW11_Drag(cfg,g,cfg.mass.max_normal_lb,cfg.reference.cruise_TAS_kt*cfg.units.kt_to_fps,a,1);
values(end+1)=abs(d.CD0-cfg.aero.CD0_target)<1e-10 && cfg.aero.misc_flatplate_ft2>=0;
labels{end+1}='No NaN or complex physical mission result';
numbers=[m.ramp_lb,m.takeoff_lb,m.final_lb,R.Cruise.CL,R.Cruise.CDT,R.Stability.alpha_deg, ...
    R.Stability.dele_up_deg,tw.power_margin_hp(m.airborne),ws.Sreqft2];
values(end+1)=all(~isnan(numbers) & ~isinf(numbers)) && isreal(numbers);
labels{end+1}='Aerobatic pulse recovers its energy without stalling';
values(end+1)=R.AerobaticEnergy.valid;
checks.labels=labels; checks.pass=logical(values);
checks.end_static_margin=SMend;
checks.count=numel(values); checks.all_pass=all(values);
if ~checks.all_pass
    failed=labels(~logical(values));
    error('bws013:ValidationFailed','Validation failed: %s',strjoin(failed,'; '));
end
end

function printResults(R)
g=R.Geometry; m=R.Mission; cfg=R.cfg; tw=R.TW;
fprintf('\nBWS013 TWO-PERSON AEROBATIC BIPLANE\n');
fprintf('Mission: %.0f nm out + %.0f nm back, %.0f min aerobatics, %.0f ft\n', ...
    cfg.mission.distance_each_nm,cfg.mission.distance_each_nm,cfg.mission.aerobatic_min,cfg.mission.altitude_ft);
fprintf('Two occupants %.1f lb + worn equipment %.1f lb + baggage %.1f lb\n', ...
    sum(cfg.mass.occupants_lb),sum(cfg.mass.worn_equipment_lb),cfg.mass.baggage_lb);
fprintf('Ramp %.2f lb; takeoff %.2f lb; aerobatic entry %.2f lb; landing %.2f lb\n', ...
    m.ramp_lb,m.takeoff_lb,m.weight_start_lb(5),m.landing_lb);
fprintf('Fuel: trip %.3f + contingency %.3f + protected reserve %.3f = %.3f usable gal\n', ...
    m.trip_gal,m.contingency_gal,m.reserve_gal,m.dispatch_gal);
fprintf('Fuel after taxi in %.3f gal (%.1f min normal-cruise equivalent); capacity %.1f gal\n', ...
    m.fuel_end_gal(end),m.nominal_land_reserve_min,cfg.fuel.main_usable_gal);
fprintf('Block time %.1f min; airborne %.1f min; reserve time is additional/unflown.\n', ...
    m.block_time_min,m.airborne_min);
fprintf('\n%-20s %6s %7s %8s %9s %8s %9s\n','Phase','min','gph','burn gal','start lb','CL','P margin');
for j=1:numel(m.names)
    fprintf('%-20s %6.2f %7.2f %8.3f %9.2f %8.3f %9.2f\n', ...
        m.names{j},m.time_min(j),m.flow_gph(j),m.burn_gal(j), ...
        m.weight_start_lb(j),tw.CL(j),tw.power_margin_hp(j));
end
fprintf('P margin is shaft hp. Ground rows have no aerodynamic power check.\n');
fprintf('The 4-g row is transient: energy rate %.1f ft/s; not a sustained turn.\n', ...
    tw.aerobatic_specific_energy_rate_fps);
fprintf('Cycle check: %.1f-s high-g pulse, %.2f-s recovery; minimum %.1f KEAS; average %.1f hp.\n', ...
    cfg.mission.aerobatic_pulse_s,R.AerobaticEnergy.recovery_time_s, ...
    R.AerobaticEnergy.minimum_EAS_kt,R.AerobaticEnergy.average_power_hp);
fprintf('\nGeometry: total area %.3f ft2, per wing %.3f, span %.2f ft\n',g.SrefW,g.S_each,g.bW);
fprintf('Physical wing root %.3f in; S/b chord %.3f in; true MAC %.3f in\n', ...
    g.crW*12,g.avgchord*12,g.cbarW*12);
fprintf('AR total %.4f; AR per wing %.4f; HT %.3f ft2; VT %.3f ft2; arm %.3f in\n', ...
    g.AR_ref,g.AR_each,g.SrefHt,g.SrefVt,g.t_arm*12);
fprintf('Estimated wetted area %.2f ft2; estimated fuselage volume %.2f ft3\n',g.Swet_total,g.volume_fuse_ft3);
fprintf('Fixed CAD elevations give overall height %.1f in vs %.1f in class reference (geometry differs).\n', ...
    12*g.overall_height_ft,cfg.reference.height_in);
fprintf('Cruise Re %.3e; CL %.4f; CD0 %.5f; CD %.5f; L/D %.2f\n', ...
    R.Airfoil.Re,R.Cruise.CL,R.Cruise.CD0,R.Cruise.CDT,R.Cruise.LD);
fprintf('Cruise trim alpha %.3f deg; elevator %.3f deg UP; static margin %.2f%%\n', ...
    R.Stability.alpha_deg,R.Stability.dele_up_deg,100*R.Stability.SM);
fprintf('Minimum phase-end static margin %.2f%% (assumed mass budget).\n',100*min(R.Validation.end_static_margin));
fprintf('Stall at takeoff weight %.2f KEAS; area required %.2f ft2 (%s).\n', ...
    R.WS.Vstall_EAS_kt,R.WS.Sreqft2,R.WS.governing);
fprintf('A 40/35 kt stall at this weight needs %.1f/%.1f ft2, not %.1f ft2.\n', ...
    R.WS.stall_target_40kt_area_ft2,R.WS.stall_target_35kt_area_ft2,g.SrefW);
fprintf('Takeoff ground roll %.0f ft; over 50 ft %.0f ft; landing over 50 ft %.0f ft (estimates).\n', ...
    tw.takeoff_groundroll_ft,tw.takeoff_over50_ft,R.WS.landing_over50_ft);
fprintf('\nPublished-condition comparisons, not mission settings:\n');
fprintf('75%% cruise at 6000 ft %.1f KTAS vs 150 reference (%+.1f%%); max sea-level %.1f vs 169 (%+.1f%%).\n', ...
    R.Benchmark.cruise75_TAS_kt,R.Benchmark.cruise_percent_difference, ...
    R.Benchmark.maximum_SL_kt,R.Benchmark.maximum_percent_difference);
fprintf('Full-power sea-level climb at mission weight %.0f fpm; 2900 published is at MINIMUM weight.\n', ...
    R.Benchmark.ROC_SL_missionweight_fpm);
fprintf('Conservative ferry cruise-leg range with this payload and reserve %.1f nm / %.1f statute mi.\n', ...
    R.Benchmark.ferry_cruise_range_nm,R.Benchmark.ferry_cruise_range_statute_mi);
fprintf('300 statute mi requires %.1f usable gal before adding aerobatics; normal capacity %.1f.\n', ...
    R.Benchmark.fuel_for_300_statute_mi_gal,cfg.fuel.normal_usable_gal);
fprintf('Checks: %d/%d PASS. Concept assumptions and source audit are in this file header.\n\n', ...
    sum(R.Validation.pass),R.Validation.count);
end

function makeAnalysisPlots(R)
cfg=R.cfg; g=R.Geometry; m=R.Mission;
figure('Name','Mission altitude and protected fuel','Color','w');
subplot(2,2,1);
plot(m.time_edges_min,[m.alt_start_ft(1),m.alt_end_ft],'b-o','LineWidth',2);
grid on; xlabel('Block time (min)'); ylabel('Altitude (ft)');
title(sprintf('%.0f-nm sortie; reserve is carried',2*cfg.mission.distance_each_nm));
subplot(2,2,3);
plot(m.time_edges_min,[m.dispatch_gal,m.fuel_end_gal],'k-o','LineWidth',2); hold on;
plot([0,m.block_time_min],[m.reserve_gal,m.reserve_gal],'r--','LineWidth',2);
grid on; xlabel('Block time (min)'); ylabel('Usable fuel (US gal)');
legend('Nominal fuel remaining','Protected reserve','Location','best');
subplot(2,2,2);
e=R.AerobaticEnergy;
plot(e.time_s,e.V_EAS_kt,'b-','LineWidth',2); grid on;
xlabel('Time in illustrative cycle (s)'); ylabel('Equivalent airspeed (kt)');
title(sprintf('%.1f-s %.0f-g pulse, then powered recovery', ...
    cfg.mission.aerobatic_pulse_s,cfg.mission.aerobatic_g));
subplot(2,2,4);
plot(e.time_s(1:end-1),e.power_hp,'k-','LineWidth',2); hold on;
plot([0,e.time_s(end)],[m.power_hp(5),m.power_hp(5)],'r--','LineWidth',1.5);
grid on; xlabel('Time in illustrative cycle (s)'); ylabel('Shaft power (hp)');
title(sprintf('Cycle closes energy; average %.1f hp',e.average_power_hp));
legend('Used','Budgeted ceiling','Location','best');

a=cfg.atmosphere(cfg.mission.altitude_ft);
speeds=linspace(55,180,251); dp=zeros(size(speeds)); di=dp; dt=dp; thrust=dp;
for j=1:numel(speeds)
    V=speeds(j)*cfg.units.kt_to_fps;
    d=bws013_HW11_Drag(cfg,g,m.weight_start_lb(4),V,a,1);
    dp(j)=d.DP; di(j)=d.DL; dt(j)=d.D;
    thrust(j)=cfg.prop.eta_cruise*cfg.mission.cruise_fraction_of_rated_power*cfg.engine.rated_hp*550/V;
end
figure('Name','HW11 - flight drag and available thrust','Color','w');
plot(speeds,dp,'b-',speeds,di,'r-',speeds,dt,'k-',speeds,thrust,'g--','LineWidth',2); hold on;
Vs=sqrt(2*m.weight_start_lb(4)/(a.rho*g.SrefW*cfg.aero.CLmax))/cfg.units.kt_to_fps;
yl=[0,max(dt)*1.05]; plot([Vs,Vs],yl,'k:','LineWidth',1.5);
grid on; xlabel('True airspeed (kt)'); ylabel('Force (lb)'); ylim(yl);
title(sprintf('Drag at %.0f ft; left of stall marker is invalid level flight',cfg.mission.altitude_ft));
legend('Parasite drag','Induced drag','Total drag','Scheduled cruise thrust','Stall TAS','Location','best');

alpha=linspace(-20,20,401);
l=bws013_HW12_Lift(cfg,g,R.Cruise.Mach,alpha,0);
CL=l.CL_T; CL(~l.valid_linear)=NaN;
figure('Name','HW12 - whole aircraft lift','Color','w');
plot(alpha,CL,'k-','LineWidth',2); grid on;
xlabel('Angle of attack (deg)'); ylabel('Aircraft C_L, neutral elevator');
title('Linear biplane lift model ends at the assumed lift limits');

cl=linspace(-cfg.aero.CLmax,cfg.aero.CLmax,301);
cd=R.Cruise.CD0+R.Cruise.k*cl.^2;
figure('Name','HW11-12 - drag polar','Color','w');
plot(cd,cl,'k-','LineWidth',2); hold on;
clopt=R.Cruise.CL_at_LDmax; cdopt=2*R.Cruise.CD0;
plot(cdopt,clopt,'ro','MarkerFaceColor','r');
plot(R.Cruise.CDT,R.Cruise.CL,'bs','MarkerFaceColor','b');
grid on; xlabel('Aircraft C_D'); ylabel('Aircraft C_L');
title('Biplane drag polar at mission cruise conditions');
legend('Parabolic model','Local maximum L/D','Trimmed cruise','Location','best');

de=linspace(-cfg.controls.elevator_limit_deg,cfg.controls.elevator_limit_deg,201);
cm=zeros(size(de));
for j=1:numel(de)
    s=bws013_HW13_StabControl(cfg,g,m.weight_start_lb(4),m.fuel_start_gal(4), ...
        R.Cruise.Mach,R.Cruise.CL,R.Stability.alpha_deg,de(j));
    cm(j)=s.Cmcg;
end
figure('Name','HW13 - elevator trim','Color','w');
plot(de,cm,'g-','LineWidth',2); hold on;
plot([min(de),max(de)],[0,0],'k:');
plot(R.Stability.dele_up_deg,0,'ko','MarkerFaceColor','k');
grid on; xlabel('Elevator deflection, trailing edge UP positive (deg)'); ylabel('C_m about mass-budget CG');
title(sprintf('Calculated trim %.2f deg UP; static margin %.1f%%', ...
    R.Stability.dele_up_deg,100*R.Stability.SM));
end
