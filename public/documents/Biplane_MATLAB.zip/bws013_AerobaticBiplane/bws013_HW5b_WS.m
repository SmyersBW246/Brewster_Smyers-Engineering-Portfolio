function ws = bws013_HW5b_WS(cfg,g,mission,tw)
% HW5b: actual loading and real requirements, not cruise optimums used as
% arbitrary upper bounds. Published geometry is never silently resized.
a0=cfg.atmosphere(0);
ws.WS_actual=mission.takeoff_lb/g.SrefW;
ws.stage_WS=mission.weight_start_lb/g.SrefW;
ws.Vstall_EAS_kt=sqrt(2*mission.takeoff_lb ...
    /(a0.rho*g.SrefW*cfg.aero.CLmax))/cfg.units.kt_to_fps;
ws.Vstall_fps=ws.Vstall_EAS_kt*cfg.units.kt_to_fps;
ws.Vcruise_TAS_fps=cfg.mission.cruise_TAS_kt*cfg.units.kt_to_fps;
ws.WS_stall=0.5*a0.rho*(cfg.requirements.stall_EAS_kt*cfg.units.kt_to_fps)^2*cfg.aero.CLmax;
f_land=mission.landing_lb/mission.takeoff_lb;
ws.WS_approach=0.5*a0.rho*(cfg.requirements.approach_EAS_kt*cfg.units.kt_to_fps/1.3)^2 ...
    *cfg.aero.CLmax/f_land;
ws.WS_maneuver=0.5*a0.rho*(cfg.mission.aerobatic_EAS_kt*cfg.units.kt_to_fps)^2 ...
    *cfg.aero.CLmax/cfg.mission.aerobatic_g;

% Takeoff loading constraint from mean acceleration at 0.7 V_LOF.
W=mission.takeoff_lb;
drag=bws013_HW11_Drag(cfg,g,W,max(0.7*tw.V_liftoff_fps,30),a0,1);
margin=@(loading) takeoffMargin(loading,cfg,W,a0,drag,tw.static_thrust_lb);
assert(margin(1)>0,'No feasible takeoff loading found.');
if margin(60)<0
    ws.WS_takeoff=fzero(margin,[1,60]);
else
    ws.WS_takeoff=Inf;
end
% Climb has a feasible interval, not only an upper limit.
j=3; a=tw.atmosphere{j}; V=tw.V_TAS_fps(j);
q=0.5*a.rho*V^2;
gamma=asind(cfg.mission.climb_fpm/60/V);
d=bws013_HW11_Drag(cfg,g,mission.weight_start_lb(j),V,a,cosd(gamma));
t=tw.T_available(j)/mission.weight_start_lb(j)-sind(gamma);
aa=d.k*cosd(gamma)^2/q; bb=-t; cc=q*d.CD0;
disc=bb^2-4*aa*cc;
assert(disc>=0,'Required climb has no feasible wing-loading interval.');
f_climb=mission.weight_start_lb(j)/mission.takeoff_lb;
ws.WS_climb_lower=(-bb-sqrt(disc))/(2*aa)/f_climb;
ws.WS_climb=(-bb+sqrt(disc))/(2*aa)/f_climb;
ws.constraint_names={'Stall','Takeoff','Approach','Climb',sprintf('%.1f-g lift',cfg.mission.aerobatic_g)};
ws.constraints=[ws.WS_stall,ws.WS_takeoff,ws.WS_approach,ws.WS_climb,ws.WS_maneuver];
[ws.WS_min,index]=min(ws.constraints);
ws.governing=ws.constraint_names{index};
ws.Sreqft2=mission.takeoff_lb/ws.WS_min;
ws.area_margin_ft2=g.SrefW-ws.Sreqft2;
ws.stall_target_40kt_area_ft2=2*mission.takeoff_lb ...
    /(a0.rho*(40*cfg.units.kt_to_fps)^2*cfg.aero.CLmax);
ws.stall_target_35kt_area_ft2=2*mission.takeoff_lb ...
    /(a0.rho*(35*cfg.units.kt_to_fps)^2*cfg.aero.CLmax);
ws.n_stall_at_aerobatic_speed=0.5*a0.rho ...
    *(cfg.mission.aerobatic_EAS_kt*cfg.units.kt_to_fps)^2*g.SrefW*cfg.aero.CLmax ...
    /mission.weight_start_lb(5);
ws.aerodynamic_six_g_speed_EAS_kt=ws.Vstall_EAS_kt*sqrt(6);

% Landing is an estimate: 50 ft / tan(3 deg) plus paved-runway braking.
Vtd=1.15*sqrt(2*mission.landing_lb/(a0.rho*g.SrefW*cfg.aero.CLmax));
ws.landing_groundroll_ft=Vtd^2/(2*cfg.units.g_fps2*cfg.ground.braking_mu);
ws.landing_over50_ft=50/tand(cfg.ground.approach_angle_deg)+ws.landing_groundroll_ft;
assert(ws.WS_actual>=ws.WS_climb_lower,'Loading below climb feasible interval.');
assert(ws.area_margin_ft2>=-1e-7,'Installed wing area does not meet requirements.');
end

function margin=takeoffMargin(loading,cfg,W,a0,drag,Tstatic)
Vlof=1.2*sqrt(2*loading/(a0.rho*cfg.aero.CLmax));
Vmean=0.7*Vlof; q=0.5*a0.rho*Vmean^2;
CLg=cfg.ground.CL_ground_fraction*cfg.aero.CLmax;
disk=pi*(cfg.prop.diameter_ft/2)^2;
Peff=cfg.prop.static_power_factor*cfg.engine.rated_hp*550;
vi=(Peff/(2*a0.rho*disk))^(1/3);
for j=1:20
    vi=vi-(vi*(Vmean+vi)^2-Peff/(2*a0.rho*disk))/((Vmean+vi)*(Vmean+3*vi));
end
T=min([Tstatic,2*a0.rho*disk*vi*(Vmean+vi), ...
    cfg.prop.eta_takeoff*cfg.engine.rated_hp*550/Vmean]);
DW=q/loading*(drag.CD0+cfg.ground.induced_factor*drag.k*CLg^2);
LW=min(q*CLg/loading,1);
margin=T/W-DW-cfg.ground.rolling_mu*(1-LW) ...
    -Vlof^2/(2*cfg.units.g_fps2*cfg.requirements.takeoff_groundroll_ft);
end
