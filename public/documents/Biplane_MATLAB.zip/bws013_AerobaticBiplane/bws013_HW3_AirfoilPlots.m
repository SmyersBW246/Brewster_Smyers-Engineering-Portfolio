function af = bws013_HW3_AirfoilPlots(cfg,g,mission,makePlots)
% HW3: NACA 0012 geometry and explicitly labeled conceptual section polar.
% MAT polar is analytical teaching data, not a wind-tunnel/XFOIL result.
% Aircraft CLmax comes from the published aircraft stall, not 2-D section Cl.
if nargin<4, makePlots=true; end
data = load(fullfile(fileparts(mfilename('fullpath')),'bws013_NACA0012.mat'));
af.profile = data.NACA0012_profile;
af.section_liftcurve = data.NACA0012_liftcurve;
af.section_dragpolar = data.NACA0012_dragpolar;
af.data_provenance = data.data_provenance;
atm = cfg.atmosphere(cfg.mission.altitude_ft);
V = cfg.mission.cruise_TAS_kt*cfg.units.kt_to_fps;
af.Re = atm.rho*V*g.cbarW/atm.mu;
af.Sref = g.SrefW;
af.Cl_design = mission.weight_start_lb(4)/(0.5*atm.rho*V^2*g.SrefW);
af.Cl_max = cfg.aero.CLmax;
atmSL = cfg.atmosphere(0);
af.Vstall_gross_EAS_kt = sqrt(2*cfg.mass.max_normal_lb ...
    /(atmSL.rho*g.SrefW*af.Cl_max))/cfg.units.kt_to_fps;
af.Vstall_mission_EAS_kt = af.Vstall_gross_EAS_kt*sqrt(mission.takeoff_lb/cfg.mass.max_normal_lb);
ld = data.NACA0012_dragpolar(:,1)./data.NACA0012_dragpolar(:,2);
[af.section_LDmax,index] = max(ld);
af.section_CL_at_LDmax = data.NACA0012_dragpolar(index,1);
if ~makePlots, return; end
figure('Name','HW3 - NACA 0012 profile','Color','w');
plot(af.profile(:,1),af.profile(:,2),'b-','LineWidth',2);
axis equal; grid on; xlabel('x/c'); ylabel('y/c');
title('Representative symmetric NACA 0012 section');
figure('Name','HW3 - section polar','Color','w');
plot(af.section_dragpolar(:,2),af.section_dragpolar(:,1),'b-','LineWidth',2);
grid on; xlabel('Section C_d'); ylabel('Section C_l');
title('Analytical pre-stall section polar - NOT measured data');
figure('Name','HW3 - lift curves','Color','w');
alpha = af.section_liftcurve(:,1);
L = bws013_HW12_Lift(cfg,g,V/atm.a_fps,alpha,0);
aircraftCL = L.CL_T; aircraftCL(~L.valid_linear)=NaN;
plot(alpha,af.section_liftcurve(:,2),'b-',alpha,aircraftCL,'k--','LineWidth',2);
hold on; plot([min(alpha),max(alpha)],[af.Cl_design,af.Cl_design],'r:','LineWidth',1.5);
grid on; xlabel('Angle of attack (deg)'); ylabel('Lift coefficient');
title('Section and biplane lift slopes use different reference definitions');
legend('2-D analytical section','Whole aircraft, neutral elevator','Cruise required C_L','Location','best');
end
