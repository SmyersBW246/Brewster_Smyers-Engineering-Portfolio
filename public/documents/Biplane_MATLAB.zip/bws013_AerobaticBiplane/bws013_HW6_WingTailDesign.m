function g = bws013_HW6_WingTailDesign(cfg)
% HW6: two lifting wings and the tail geometry accepted in the CAD work.
% All aerodynamic coordinates: x aft from spinner, y spanwise, z up (ft).
% SrefW ALWAYS means upper PLUS lower wing area. No single-wing AR is
% substituted into a coefficient defined using total wing area.

g.SrefW = cfg.geometry.S_total_ft2;
g.S_each = g.SrefW/2;
g.bW = cfg.geometry.span_ft;
g.AR_ref = g.bW^2/g.SrefW;
g.AR_each = g.bW^2/g.S_each;
g.avgchord = g.S_each/g.bW;
g.L_fuse = cfg.geometry.length_ft;
g.gap_ft = cfg.geometry.gap_ft;
g.stagger_aft_ft = cfg.geometry.stagger_aft_ft;
g.x_lower_LE_ft = cfg.geometry.lower_LE_x_ft;
g.z_lower_ft = cfg.geometry.lower_z_ft;

% Stadium outline: central rectangle and two semicircular tips. The small
% quadratic root preserves the published area, unlike using S/b as the
% physical root chord of a rounded-tip wing.
A = 1-pi/4;
g.crW = 2*g.S_each/(g.bW+sqrt(g.bW^2-4*A*g.S_each));
g.ctW = 0;                          % actual chord at the rounded tip
g.Wsweep = 0;                       % straight center panel, degrees
g.yW = linspace(-g.bW/2,g.bW/2,10001);
d = max(abs(g.yW)-(g.bW-g.crW)/2,0);
g.cW = 2*sqrt(max((g.crW/2)^2-d.^2,0));
g.cbarW = trapz(g.yW,g.cW.^2)/g.S_each;
g.ybarW = trapz(g.yW,abs(g.yW).*g.cW)/g.S_each;
g.x_wing_ac_ft = g.x_lower_LE_ft+g.stagger_aft_ft/2 ...
    +g.crW/2-g.cbarW/4;
g.x_mac_LE_ft = g.x_wing_ac_ft-g.cbarW/4;

% October CAD files: HT root LE x=113 in, TE x=143 in, y=-35.5 in;
% tip chord 26.28 in at z=49.25 in. CAD lower-wing LE is (0,-45,0) in.
% Thus z_tail-z_lower = 9.5 in in the aerodynamic coordinate convention.
g.bHt = 2*cfg.geometry.HT_halfspan_in/12;
g.crHt = cfg.geometry.HT_root_in/12;
g.ctHt = cfg.geometry.HT_tip_in/12;
g.lamHt = g.ctHt/g.crHt;
g.SrefHt = g.bHt*(g.crHt+g.ctHt)/2;
g.AR_Ht = g.bHt^2/g.SrefHt;
g.cbarHt = (2/3)*g.crHt*(1+g.lamHt+g.lamHt^2)/(1+g.lamHt);
g.ybarHt = (g.bHt/6)*(1+2*g.lamHt)/(1+g.lamHt);
g.Htsweep = 0;                     % LE sweep, not TE taper angle
g.HT_TE_taper_deg = atand((g.crHt-g.ctHt)/(g.bHt/2));
g.x_HT_LE_ft = g.x_lower_LE_ft+cfg.geometry.HT_LE_from_lower_in/12;
g.x_HT_ac_ft = g.x_HT_LE_ft+g.cbarHt/4;
g.z_HT_ft = g.z_lower_ft+cfg.geometry.HT_above_lower_in/12;

g.bVt = cfg.geometry.VT_height_in/12;
g.crVt = cfg.geometry.VT_root_in/12;
g.ctVt = cfg.geometry.VT_tip_in/12;
g.Vtsweep = cfg.geometry.VT_LE_sweep_deg;
g.SrefVt = g.bVt*(g.crVt+g.ctVt)/2;
g.AR_Vt = g.bVt^2/g.SrefVt;
lv = g.ctVt/g.crVt;
g.cbarVt = (2/3)*g.crVt*(1+lv+lv^2)/(1+lv);
g.x_VT_LE_ft = g.x_lower_LE_ft+cfg.geometry.VT_LE_from_lower_in/12;
g.zbarVt = (g.bVt/3)*(1+2*lv)/(1+lv);
g.x_VT_ac_ft = g.x_VT_LE_ft+g.zbarVt*tand(g.Vtsweep)+g.cbarVt/4;
g.t_arm = g.x_HT_ac_ft-g.x_wing_ac_ft;
g.t_arm_Vt = g.x_VT_ac_ft-g.x_wing_ac_ft;
g.VH = g.SrefHt*g.t_arm/(g.SrefW*g.cbarW);
g.VV = g.SrefVt*g.t_arm_Vt/(g.SrefW*g.bW);

% Surface estimates, not measured CAD areas. Elliptical fuselage sections
% come from the earlier loft station table; canopy is included in this hull.
g.fuse_x = cfg.geometry.fuse_station_in/12;
g.fuse_w = cfg.geometry.fuse_width_in/12;
g.fuse_h = cfg.geometry.fuse_height_in/12;
a = g.fuse_w/2; b = g.fuse_h/2;
perimeter = pi*(3*(a+b)-sqrt((3*a+b).*(a+3*b)));
r = sqrt(a.*b);
ds = sqrt(diff(g.fuse_x).^2+diff(r).^2);
g.Swet_fuse = sum((perimeter(1:end-1)+perimeter(2:end)).*ds/2);
g.volume_fuse_ft3 = trapz(g.fuse_x,pi*a.*b);
g.d_fuse_eq_ft = max(sqrt(g.fuse_w.*g.fuse_h));
g.Swet_wing = 2.04*g.SrefW;
g.Swet_Htail = 2.04*g.SrefHt;
g.Swet_Vtail = 2.04*g.SrefVt;
g.strut_length_ft = 2*g.gap_ft+4*cfg.geometry.cabane_length_ft;
g.Swet_struts = 2*g.strut_length_ft*cfg.geometry.strut_chord_ft;
g.Swet_total = g.Swet_wing+g.Swet_Htail+g.Swet_Vtail ...
    +g.Swet_fuse+g.Swet_struts;
g.Swet_Sref = g.Swet_total/g.SrefW;
g.overall_height_ft=max([g.z_HT_ft+g.bVt, ...
    g.z_lower_ft+g.gap_ft+0.06*g.crW, ...
    max(cfg.geometry.fuse_center_z_in/12+g.fuse_h/2)]);
assert(g.t_arm>0 && g.SrefW>0,'Invalid wing/tail geometry.');
assert(abs(trapz(g.yW,g.cW)-g.S_each)<1e-3,'Wing outline area mismatch.');
end
